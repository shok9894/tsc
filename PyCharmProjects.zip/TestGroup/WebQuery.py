from selenium import webdriver
from selenium.webdriver.common import keys
import data
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
from selenium.webdriver.common.by import By
from selenium.webdriver import remote

profile = webdriver.FirefoxProfile()  # Объявляю переменную для настройки профайла в FireFox
profile.accept_untrusted_certs = True  # Игнорирование серитификатов
# self.driver = webdriver.Firefox(firefox_profile="C:\\Users\\IShakirov\\AppData\\Roaming\\Mozilla\\Firefox\\Profiles\\h3a32irl.default")
driver = webdriver.Firefox(firefox_profile=profile, proxy="proxy.tsc.ts:8080")
#driver = webdriver.Firefox()
driver.get("https://dedgetsc4.dedic.renter.ru:9444/ProcessPortal/dashboards/SYSRP/RESPONSIVE_WORK")
driver.implicitly_wait(10)
driver.set_page_load_timeout(10)
driver.set_script_timeout(10)
is_ok = ''

try:
    is_ok = WebDriverWait(driver, 10).until(EC.presence_of_element_located((By.XPATH, './/*[@id=\'username\']')))
    print(is_ok)
except:
    print('TimeOutException1')
login = driver.find_element_by_xpath('//*[@name=\'j_username\']').send_keys(*data.allData.login)
password = driver.find_element_by_xpath('//*[@name=\'j_password\']').send_keys(data.allData.password)
click_go = driver.find_element_by_xpath('//*[@name=\'j_username\']').send_keys(keys.Keys.ENTER)

frame = driver.find_element_by_tag_name('iframe')
frame_id = frame.get_attribute('id')
print(frame_id)
driver.switch_to_frame(frame_id)
page = driver.page_source
print('title="Просмотр заявки в XML"' in page)
try:
    is_ok = WebDriverWait(driver, 25).until(EC.element_to_be_clickable('//*[@title="Просмотр заявки в XML"]'))
except:
    print('TimeoutException2')

try:
    element = driver.find_element_by_xpath('//*[@title="Просмотр заявки в XML"]')
except:
    print('Trouble')


try:
    WebDriverWait(driver, 10).until(EC.visibility_of((By.XPATH, '//*[@name="text"]')))
except:
    print('TimeoutException3')
type_n = driver.find_element_by_xpath('//*[@name="text"]').send_keys('2b9c2e3c-819d-41a0-abef-3237b5f36d08')

input()
def close(self):
    driver.close()

