import requests
from lxml import etree, html
if 0:
    url = 'http://dedgetsc1.dedic.renter.ru:9080/askk-referencesWeb/sca/BlackListCheckWSExport'
    header_content = {'Content-type': 'text/xml'}
    soap_str = '<soapenv:Envelope xmlns:soapenv="http://schemas.xmlsoap.org/soap/envelope/" ' \
           'xmlns:chec="http://askk-references/blacklists/checks">' \
           '<soapenv:Header/>' \
           '<soapenv:Body>' \
           '<chec:checkPhone>' \
           '<phoneNumber>9152911352' \
           '</phoneNumber>' \
           '</chec:checkPhone>' \
           '</soapenv:Body>' \
           '</soapenv:Envelope>'
    response = requests.post(url, data=soap_str, headers=header_content, verify=False)
    xml = open('xml.xml', 'w', encoding='UTF-8')
    xml.write(response.text)
    xml.close()

    et = etree.parse('xml.xml')
    element = et.xpath('//description/../*')
    for el in element:
        pass
    #print(el.tag, el.text)


def subjects():
    et = etree.parse('app.xml')

    element = et.xpath('//legalAttributes/fullName')
    YL = [i.text+' ЮЛ' for i in element]

    element = et.xpath('//privateAttributes[not(parent::entrAttributes)]/actualName/surname')
    FL = [i.text for i in element]

    element = et.xpath('//entrAttributes/shortName')
    IP = [i.text+' ИП' for i in element]

    return YL,FL,IP

#print('YL',YL,'\nFL',FL,'\nIP',IP)

def m():
    while True:
        x = input('Insert your XPath expression, or Exit for exit:\n>>')

        try:
            if x.lower() == 'exit':
                print('Goodbay')
                break
            else:
                element = et.xpath(x)
                for el in element:
                    if 'tag' in dir(el):
                        print(el.tag, end='')
                    if 'text' in dir(el):
                        print(':', el.text.strip('\n '), '\n', end='')
                    elif str(el).strip() == '':
                        continue
                    else:
                        print(el)

                print('Rows', element.__len__())
        except Exception as err:
            print(err)
            continue


pass
