from requests import auth
import requests
import json

# session = requests.Session()
# payload = {'page': '0', 'pagesize': '9999999'}

# res = requests.get(
#     'http://bcvm635.tsc.ts:8080/kie-server/services/rest/server/queries/processes/instances?pageSize=9999999&page=0',
#     proxies=proxies, auth=auth.HTTPBasicAuth('bpm_rest', 'bpm_rest'), )


# pInstanceId = 1869
# res = requests.delete(
#     'http://bcvm635:8080/kie-server/services/rest/server/containers/hardcollect/processes/instances/%s' % pInstanceId,
#     proxies=proxies, auth=auth.HTTPBasicAuth('bpm_rest', 'bpm_rest'), )
proxy_User = 'isizov'
proxy_password = 'aa11aa11'
proxies = {'http': 'http://%s:%s@proxy.tsc.ts:8080/' % (proxy_User, proxy_password)}


def kill_instance(instanceId, proxy=proxies):
    proxies = proxy
    result = requests.delete(
        'http://bcvm635:8080/kie-server/services/rest/server/containers/hardcollect/processes/instances/%s' % instanceId,
        proxies=proxies, auth=auth.HTTPBasicAuth('bpm_rest', 'bpm_rest'), )
    print('\nText:', result.text, '\nReason:', result.reason, '\nOk:', result.ok)


# kill_instance(29966)
def delegate(tInstanceId, targetUser, proxy_User='isizov', proxy_password='aa11aa11'):
    proxies = {'http': 'http://%s:%s@proxy.tsc.ts:8080/' % (proxy_User, proxy_password)}
    result = requests.put(
        'http://bcvm635.tsc.ts/kie-server/services/rest/server/containers/hardcollect/tasks/%(tInstanceId)s/states/delegated?user=%(user)s&targetUser=%(user)s' % {
            'tInstanceId': tInstanceId, 'user': 'tbobyleva.RF.03'},
        proxies=proxies, auth=auth.HTTPBasicAuth('bpm_rest', 'bpm_rest'), )
    print(result.text)


# delegate(3927, 'lider.RF.23')
kill_instance(88847)

proxies = {'http': 'http://%s:%s@proxy.tsc.ts:8080/' % ('isizov', 'shok9894')}


def login(user='user0002.ad.3', password='user0002.ad.3', proxy_User='isizov', proxy_password='shok9894'):
    result = requests.get(
        'http://bcvm635.tsc.ts/collect-api/login?j_username=%(user)s&j_password=%(password)s' % {'user': user,
                                                                                                 'password': password},
        proxies=proxies)
    # print('\nText:', result.text, '\nReason:', result.reason, '\nOk:', result.ok)
    return result.cookies


# cookies = login()


def debtsearch(text='авто', password='user0002.ad.3', proxy_User='isizov', proxy_password='shok9894'):
    proxies = {'http': 'http://%s:%s@proxy.tsc.ts:8080/' % (proxy_User, proxy_password)}

    result = requests.get(
        'http://bcvm635.tsc.ts/collect-api/rest/cards?text=%s&ctype=legal' % text,
        proxies=proxies, cookies=cookies)
    # print('\nText:', result.text, '\nReason:', result.reason, '\nOk:', result.ok)
    return [result.json(), result.cookies]


def clientcard_tabs(clientId):
    clientcard = requests.get('http://bcvm635.tsc.ts/collect-api/rest/clientCard/%s' % clientId,
                              proxies=proxies, cookies=cookies)
    clientcard_id = clientcard.json()

    result = requests.get(
        'http://bcvm635.tsc.ts/collect-api/rest/card/%s/tabs' % clientcard_id['data']['clientCard']['id'],
        proxies=proxies, cookies=cookies)
    return result.json()


# json_result, cookies = debtsearch()
def d():
    for val in json_result['data']:
        tabs = clientcard_tabs(val['clientIdentityId'])
        if tabs['data']['lawActionsResult']:
            print(
                '\nName:', val['name'],
                '\ninn:', val['inn'],
                '\nClient card:', 'http://bcvm635.tsc.ts/ui/#/debtorRegistration?clientId=%s' % val['clientIdentityId'],
            )
        # else:
    #     print('*' * 80, tabs['data']['lawActionsResult'])
