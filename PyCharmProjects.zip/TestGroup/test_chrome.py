import unittest
from selenium import webdriver
import login
# import page
from page import MainOperations
import SF1
import SF2
import SF3
import SF5
import SF4
import SF6
import SF7
import SF8
import SF9
import SF10
import SF11
from locators import *
import DataBaseConnect


class PythonOrgSearch(unittest.TestCase):
    @classmethod
    def setUpClass(self):
        # profile = webdriver.FirefoxProfile()  # Объявляю переменную для настройки профайла в FireFox
        # profile.accept_untrusted_certs = True  # Игнорирование серитификатов
        phantomJS_path = r"D:\Selenium\phantomjs-2.1.1-windows\bin\phantomjs.exe"
        service_args = [
            '--proxy=proxy.tsc.ts:8080',
            '--proxy-type=http',
            '--proxy-auth=ishakirov:shok9894'
        ]

        # self.driver = webdriver.Firefox(firefox_profile="C:\\Users\\IShakirov\\AppData\\Roaming\\Mozilla\\Firefox\\Profiles\\h3a32irl.default")
        # self.driver = webdriver.Firefox(firefox_profile=profile, proxy="proxy.tsc.ts:8080")
        # self.phantomjs = webdriver.PhantomJS(executable_path=phantomJS_path, service_args=service_args)
        # print('sadasd')
        # self.phantomjs.get("https://dedgetsc4.dedic.renter.ru:9444/sme/login")
        self.driver = webdriver.Chrome(r"D:\Selenium\chromedriver.exe")
        # self.chrome.get("https://dedgetsc4.dedic.renter.ru:9444/sme-dev/login")
        # self.ie = webdriver.Ie()
        self.driver.implicitly_wait(3)
        self.driver.get("https://dedgetsc4.dedic.renter.ru:9444/sme/login")

    def test1(self):
        assert self.notest_1f()

    def notest_1f(self):
        print('=' * 40, 'Start first test', '=' * 40)
        # login_page = page.LoginPage(self)
        # login_page.WaitPageShow()
        # login.login_1.log_in(self)  # Процесс логина
        login.login_1.log_in(self)
        sf = int(input('Какую выберешь форму 1-11? '))
        if sf == 1:
            MainOperations.click_choose_form(self, (CommonLocators.ChooseForm_01))  # Выбор первой экранной формы
            MainOperations.Wait_SF_load(self, (
            CommonLocators.Verify_SF_01))  # Ожидание загрузки SF (screen form) - ЭФ (экранная форма)

            # Screen_form_1.verify_atrib_contents(self, Screen_form_1.get_list_atrrib(self))  # Проверка отображения атрибутов на ЭФ
            SF1.Page.fillform1(self)

        elif sf == 2:
            MainOperations.click_choose_form(self, (CommonLocators.ChooseForm_02))
            MainOperations.Wait_SF_load(self, (CommonLocators.Verify_SF_02))
            SF2.Page.fillform2(self)

        elif sf == 3:
            MainOperations.click_choose_form(self, (CommonLocators.ChooseForm_03))
            MainOperations.Wait_SF_load(self, (CommonLocators.Verify_SF_03))
            SF3.Page.fillform3(self)

        elif sf == 4:
            MainOperations.click_choose_form(self, (CommonLocators.ChooseForm_04))
            MainOperations.Wait_SF_load(self, (CommonLocators.Verify_SF_04))
            SF4.Page.fillform4(self)

        elif sf == 5:
            SF5.Page.fillform5(self)

        elif sf == 6:
            SF6.Page.fillform6(self)

        elif sf == 7:
            SF7.Page.fillform7(self)

        elif sf == 8:
            SF8.Page.fillform8(self)

        elif sf == 9:
            SF9.Page.fillform9(self)

        elif sf == 10:
            SF10.Page.fillform10(self)

        elif sf == 11:
            SF11.Page.fillform11(self)

        return True

    #
    # def notest_1_2_1F(self):
    #     # print('Заполняется ЭФ-1.2.1\n', '-'*80)
    #
    #     assert ('Проверка комплектности и ' in self.driver.page_source), 'Форма не загрузилась'
    #     list_sections = self.driver.find_elements_by_xpath(
    #         '//div[@style="margin-left: 37px;"]//ancestor::div[contains(@class,"accordion_")]')
    #     list_subject = self.driver.find_elements_by_xpath(
    #         '//div[@style="padding: 8px 0px; float: left; width: 15%;"]/div')
    #     for subject in range(list_subject.__len__()):
    #         list_subject[subject] = list_subject[subject].text
    #
    #     new_list = list()
    #     for section in list_sections:
    #         new_list.append(section.text)
    #     conn = DataBaseConnect.connect_db()
    #     cursor = conn.cursor()
    #     query = 'select ' \
    #             'INTERNALID, ' \
    #             'PARENTID, ' \
    #             'LEVEL, ' \
    #             'NAME ' \
    #             'from REF_122_GROUP_DOC ' \
    #             'where level=2 ' \
    #             'START with name=\'ИП\' ' \
    #             'CONNECT BY PRIOR INTERNALID=PARENTID'
    #     result = cursor.execute(query)
    #
    #     result = result.fetchall()
    #     try:
    #         DataBaseConnect.connect_close(conn)
    #     except Exception as err:
    #         print('Ошибочка:', err)
    #
    #     res = list()
    #     for raw in result:
    #         res.append(str(raw[3]).upper())
    #     sr = res in new_list
    #     xsr = set(res) ^ set(new_list)
    #     print(sr, xsr)
    #     #        for raw in res:
    #     #            print(str(raw).upper())
    #     #            print('Is section', raw, 'in page:', str(raw).upper() in new_list)
    #
    #     n_section = 0
    #     for i in self.driver.find_elements_by_xpath('//div[@style="margin-left: 37px;"]'):
    #         print(i.text)
    #         if 'white' in list_sections[n_section].get_attribute('class'):
    #             i.click()
    #         n_section += 1
    #         for x in self.driver.find_elements_by_xpath("//input[@name='YesNoFieldDiv' and @value='Yes']"):
    #             x.click()
    #     self.driver.find_element_by_xpath(
    #         '//div[@style="padding-bottom: 8px;"]//*[contains(text(),\'Вперед\')]').click()
    #
    #     return True
    #
    # def notest_1_2_2F(self):
    #     print('Заполняется ЭФ-1.2.2')
    #     print('Are we load SF-1.2.2? - ', ('Сведения по выручке ' in self.driver.page_source))
    #     assert ('Сведения по выручке ' in self.driver.page_source)
    #     list_sections = self.driver.find_elements_by_xpath(
    #         '//div[@style="margin-left: 37px;"]//ancestor::div[contains(@class,"accordion_")]')
    #     n_sections = 0
    #     for section in list_sections:
    #         print('%d(%d) Зполняю секцию:' % (n_sections + 1, list_sections.__len__()), section.text, '\n', '-' * 80)
    #         if 'accordion_white' == list_sections[n_sections].get_attribute('class'):
    #             section.click()
    #         list_bloks = self.driver.find_elements_by_xpath(
    #             '//div[@class="selectedAcc"]//div[contains(@class,"accordion_")]')
    #         if list_bloks.__len__() != 0:
    #             n_blok = 0
    #             for blok in list_bloks:
    #                 print('%d(%d).%d(%d) Заполняю блок:' % (n_sections + 1, list_sections.__len__(),
    #                                                         n_blok + 1, list_bloks.__len__()), blok.text, '\n',
    #                       '-' * 80)
    #                 if 'accordion_white' in list_bloks[n_blok].get_attribute('class'):
    #                     blok.click()
    #                 n_blok += 1
    #                 list_yes_on_blok = self.driver.find_elements_by_xpath(
    #                     "//input[@name='YesNoFieldDiv' and @value='Yes']")
    #                 for yes in list_yes_on_blok:
    #                     yes.click()
    #         list_yes_on_section = self.driver.find_elements_by_xpath("//input[@name='YesNoFieldDiv' and @value='Yes']")
    #         for yes in list_yes_on_section:
    #             yes.click()
    #         n_sections += 1
    #     self.driver.find_element_by_xpath(
    #         '//div[@style="padding-bottom: 8px;"]//*[contains(text(),\'Вперед\')]').click()
    #     return True
    #
    # def notest_1_2_3F(self):
    #     print('Заполняется ЭФ-1.2.3')
    #     print('Are we load SF-1.2.3? - ', ('Основная информация' in self.driver.page_source))
    #     assert ('Основная информация' in self.driver.page_source)
    #     list_sections = self.driver.find_elements_by_xpath(
    #         '//div[@style="margin-left: 37px;"]//ancestor::div[contains(@class,"accordion_")]')
    #     n_sections = 0
    #     for section in list_sections:
    #         print('%d(%d) Зполняю секцию:' % (n_sections + 1, list_sections.__len__()), section.text,
    #               '\n', '-' * 80)
    #         if 'accordion_white' == list_sections[n_sections].get_attribute('class'):
    #             section.click()
    #         list_bloks = self.driver.find_elements_by_xpath(
    #             '//div[@class="selectedAcc"]//div[contains(@class,"accordion_")]')
    #         if list_bloks.__len__() != 0:
    #             n_blok = 0
    #             for blok in list_bloks:
    #                 print('%d(%d).%d(%d) Заполняю блок:' % (n_sections + 1, list_sections.__len__(),
    #                                                         n_blok + 1, list_bloks.__len__()), blok.text, '\n',
    #                       '-' * 80)
    #                 if 'accordion_white' in list_bloks[n_blok].get_attribute('class'):
    #                     blok.click()
    #                 n_blok += 1
    #                 list_yes_on_blok = self.driver.find_elements_by_xpath(
    #                     "//input[@name='YesNoFieldDiv' and @value='Yes']")
    #                 for yes in list_yes_on_blok:
    #                     yes.click()
    #         list_yes_on_section = self.driver.find_elements_by_xpath("//input[@name='YesNoFieldDiv' and @value='Yes']")
    #         for yes in list_yes_on_section:
    #             yes.click()
    #         n_sections += 1
    #     self.driver.find_element_by_xpath(
    #         '//div[@style="padding-bottom: 8px;"]//*[contains(text(),\'Вперед\')]').click()

    @classmethod
    def tearDownClass(self):
        print('TearDown class')
        # self.driver.close()
        print('Не забудь закрыть все')


if __name__ == "__main__":
    unittest.main()
