import DataBaseConnect
from locators import SF_2


class Page(object):
    def __init__(self, driver):
        self.driver = driver

    def fillform2(self):
        element = self.driver.find_element_by_xpath
        elements = self.driver.find_elements_by_xpath
        # try:
        #     actual_name_form = element(
        #         '//div[@class="accordion_grey"]').text
        # except Exception as err:
        #     print(err)
        criterias = elements(SF_2.criterias)
        criterias = [x.text for x in criterias]
        conn = DataBaseConnect.connect_db()
        cursor = conn.cursor()
        try:
            list_criteria = cursor.execute('select VALUE from DAT_113_CR_TRUSTWORTHINESS').fetchall()
            list_criteria = [x[0] for x in list_criteria]
        except Exception as err:
            print('Ошибочка при выполнении выборки:', err)
        x = set(criterias) ^ set(list_criteria)
        [print(i) for i in x if x]
        DataBaseConnect.connect_close(cursor=cursor, conn=conn)
        inputs = elements("//div[@class='dropDownArea']")
        inputs[0].click()
        element('//div[@class="dropDownMenu"]/div').click()
        inputs[1].click()
        element('//div[@class="dropDownMenu"]/div[2]').click()
        inputs[2].click()
        element('//div[@class="dropDownMenu"]/div[2]').click()
        inputs[3].click()
        element('//div[@class="dropDownMenu"]/div').click()

        element(SF_2.button_finish).click()
