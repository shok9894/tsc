from selenium.webdriver.support.wait import WebDriverWait
from data import *
from locators import *
from selenium.webdriver.support import expected_conditions as EC
import time

class Page(object):
    def __init__(self, driver):
        self.driver = driver

    def fillform9(self):
        def chose(locator, value):
            try:
                self.driver.find_element_by_xpath(locator).click()
                self.driver.find_element_by_xpath(value).click()
            except Exception as err:
                print(err)

        def entr(locator, val):
            x = self.driver.find_element_by_xpath(locator)
            x.clear()
            x.send_keys(val)

        l = SF_9
        # d = data.SF9_Data
        elements = self.driver.find_elements_by_xpath
        element = self.driver.find_element_by_xpath

        self.driver.find_element(*CommonLocators.rrr).click()
        self.driver.find_element(*CommonLocators.ChooseForm_09).location_once_scrolled_into_view
        self.driver.find_element(*CommonLocators.ChooseForm_09).click()
        try:
            WebDriverWait(self.driver, allData.wait_time).until(
                                                        lambda x:
                                                                x.find_element(*CommonLocators.Verify_SF_09)
                                                                .is_displayed()
                                                                )
        except Exception as err:
            print('Scren form don\'t load\n\033[31mTest failure!\033[0m')
            print(err)
            return False
        for x in elements(l.non_opened_sections):
            x.click()
            for y in elements(l.non_opened_sections):
                y.click()

        for x in elements(l.all_links):
            x.location_once_scrolled_into_view
            x.click()
            try:
                WebDriverWait(self.driver, allData.wait_time).until(EC.new_window_is_opened(self.driver.window_handles))
            except Exception as err:
                print(err)

            self.driver.switch_to.window(self.driver.window_handles[1])
            self.driver.close()
            self.driver.switch_to.window(self.driver.window_handles[0])

        for x in elements(l.informaciya_po_cerditnomy_dogovoru):
            x.location_once_scrolled_into_view
            x.click()
            try:
                WebDriverWait(self.driver, allData.wait_time).until(
                    lambda x: x.find_element_by_xpath(l.verify_opened_information).is_displayed())
            except Exception as err:
                print(err)
            time.sleep(1)
            element(l.button_back).click()

        for x in elements(l.podtverzdenies):
            x.click()

        element(l.button_finish).click()
