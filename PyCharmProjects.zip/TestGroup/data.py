class allData(object):
    login = "ishakirov"
    password = "234asd"
    login_page_title = "RSHB SME"
    base_page_title = "РСХБ СМЕ"
    wait_time = 10
    Radio_Quality_Scan_Value = 'Yes'


class SF4_Data(object):
    chislo_polnix_let_raboti_Zaemshika = 3
    chislo_polnix_let_osnovnogo_sobstvenika = 3
    data_pervogo_postupleniya_viruchki = '01.01.2010'
    kolichestvo_rabotneykov_Subekta = 120
    apk_dannye_o_strahovanii_Zaemshchikom_selsko_xozyaistvennyx_riskov = \
        'Данные о страховании Заемщиком сельскохозяйственных рисков'
    apk_dannye_o_nalichii_v_shtate_neobhodimyh_profilnyx_specialistow = \
        'Данные о наличии в штате необходимых профильных специалистов'
    fizicheskii_pokazatel_declariruemoe = 0
    fizicheskii_pokazatel_fakticheskoe = 0
    informaciya_o_biznese = 'Информация о бизнесе'
    postavshik_dolia_krupneishego_kontragenta = 100
    postavshik_kolichestvo = 1
    pokupateli_dolia_krupneishego_kontragenta = 100
    pokupateli_kolichestvo = 1
    empty = ''
    zero = 0

    active_denezhnye_sredstva_v_kasse = 29000
    active_denezhnye_sredstva_na_schetax = 50000
    active_tovary = 900000
    active_zdaniia_i_sooruzheniia = 3547000
    passive_dolgosrochnye_kredity = 978000
    passive_kratkosrochnye_kredity = 158000
    passive_nakoplennyi_kapital = 3390000
    # ОПиУ
    nacenka_po_tovary1 = 40
    viruchka_ot_prodajy_tovara1 = 617000
    prochie_doxody = 27000
    sebestoimost_tovara1 = 439000
    arenda_komunalnye_platezi = 5000
    zarplata_s_nachisleniyami = 30000
    transportnie_rasxody = 50000
    uslugi_banka_i_svyazy = 5000
    prochie_postoyannie_rasxody = 5000
    pogashenie_dolga_v_RSHB = 24000
    zona_otvetstvennosti = 'зона_ответственности'
    # Расшифровка финансовой информации
    dlytelnost_kartoteki = 1
    viruchka = viruchka_ot_prodajy_tovara1
    pribl_ubytok = 79000
    oboroty_po_rs = 490000
    sredniaia_vyruchka_dlya_celei_opredeleniya_potentciala = viruchka
    viruchka_po_dannim_offical_otchetnosti = viruchka
    pribl_ubytok_po_dannim_offical_otchetnosti = pribl_ubytok
    # Общая информация
    credit_level_prinyatiya_resheniya = 'уроень_принятия_решения'
    sobstvennyi_kapital_na_Data_2 = passive_nakoplennyi_kapital
    sobstvennyi_kapital_na_Data_3 = passive_nakoplennyi_kapital
    nakoplennaya_chistaya_pribyl = passive_nakoplennyi_kapital
    # Нефинансовые факторы
    b11 = 'b11 = "text"'
    b16 = 'b16 = "text"'
    b20 = 'b20 = "text"'
    b21 = 'b21 = "text"'
    b22 = 'b22 = "text"'
    b23 = 'b23 = "text"'
    b24 = 'b24 = "text"'
    b28 = 'b28 = "text"'
    c16 = '99'


class SF5_Data(object):
    text = 'some_text'


class SF6_Data(object):
    text = 'some_text'


class SF7_Data(object):
    text = 'some_text'


class SF8_Data(object):
    text = 'some_text'

