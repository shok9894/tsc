import unittest
from selenium import webdriver

class testClass(unittest.TestCase):

    def setUp(self):
        self.driver = webdriver.Firefox()
        self.driver.get("https://www.yandex.ru")
        self.driver.implicitly_wait(10)

    def test_log_in(self):
        element_input = self.driver.find_element_by_xpath('//input[@id="text"]')
        element_input.send_keys('Selenium')
        element_button_find = self.driver.find_element_by_xpath('//div[@class="search2__button"]/button')
        element_button_find.click()
        try:
            self.driver.find_element_by_link_text('Selenium - Web Browser Automation')
        except Exception as err:
            print('Some error:', err)

    def tearDown(self):
        print("Close browser")
        self.driver.close()

if __name__ == "__main__":
    unittest.main()


