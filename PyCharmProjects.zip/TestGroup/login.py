from selenium.webdriver.support.wait import WebDriverWait
from data import *
from locators import *


class login_1(object):
    def __init__(self, driver):
        self.driver = driver

    def log_in(self):
        print("Start process log-in")
        try:
            WebDriverWait(self.driver, allData.wait_time).until(lambda x:
                                                                x.find_element(*LoginPageLocators.InputLogin)
                                                                .is_displayed()
            )
        except Exception as err:
            print('Кажется страница не загружена\n', err)
            return False

        self.driver.find_element(*LoginPageLocators.InputLogin).send_keys(*allData.login)
        self.driver.find_element(*LoginPageLocators.InputPassword).send_keys(*allData.password)
        self.driver.find_element(*LoginPageLocators.GO_BUTTON).click()
        try:
            WebDriverWait(self.driver, allData.wait_time).until(lambda x:
                                                                x.find_element(*CommonLocators.rrr)
                                                                .is_displayed()
            )
        except Exception as err:
            print('Не дождался главной страницы', err)
            return False
        print('Log-in successful ')
        self.driver.find_element(*CommonLocators.rrr).click()
