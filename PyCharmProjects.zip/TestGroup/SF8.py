from selenium.webdriver.support.wait import WebDriverWait
from data import *
from locators import *


class Page(object):
    def __init__(self, driver):
        self.driver = driver

    def fillform8(self):
        def chose(locator, value):
            try:
                self.driver.find_element_by_xpath(locator).click()
                self.driver.find_element_by_xpath(value).click()
            except Exception as err:
                print(err)

        def entr(locator, val):
            x = self.driver.find_element_by_xpath(locator)
            x.clear()
            x.send_keys(val)

        l = SF_8
        d = data.SF8_Data
        elements = self.driver.find_elements_by_xpath
        element = self.driver.find_element_by_xpath

        self.driver.find_element(*CommonLocators.rrr).click()
        self.driver.find_element(*CommonLocators.ChooseForm_08).click()
        try:
            WebDriverWait(self.driver, allData.wait_time).until(lambda x:
                                                                x.find_element(*CommonLocators.Verify_SF_08)
                                                                .is_displayed())
        except:
            print('Scren form don\'t load\n\033[31mTest failure!\033[0m')
            return False

        element(l.section_bux_balanse).click()
        for el in elements(l.podtverzdenie):
            el.click()
            element(l.podtverzdenie_val).click()
        element(l.section_bux_balanse).click()

        element(l.section_otchet).click()
        for el in elements(l.podtverzdenie):
            el.click()
            element(l.podtverzdenie_val).click()
        element(l.section_otchet).click()

        element(l.section_finans).click()
        for el in elements(l.podtverzdenie):
            el.click()
            element(l.podtverzdenie_val).click()
        element(l.section_finans).click()

        element(l.section_pokazateli).click()
        for el in elements(l.podtverzdenie):
            el.click()
            element(l.podtverzdenie_val).click()
        element(l.section_pokazateli).click()

        element(l.section_predup).click()
        for el in elements(l.podtverzdenie):
            el.click()
            element(l.podtverzdenie_val).click()
        element(l.section_predup).click()
        element(l.button_next).click()

        # 8.2 Заключение Андрерайтера
        entr(l.gsk_uchastniki_sdelki, d.text)
        for el in elements(l.anderraiter_soglasen_uchastniki_sdelki):
            el.click()
        element(l.section_uchastniki_sdelki).click()
        element(l.section_zaprosheno).click()
        chose(l.forma_predostavleniya_zaprosheno, l.forma_predostavleniya_zaprosheno_val)
        element(l.section_zaprosheno).click()
        element(l.section_vivod_and_recomend).click()
        chose(l.znachenie_vivod, l.znachenie_vivod_val)
        entr(l.obosnavanie_vivod, d.text)
        element(l.button_next).click()
        # 8.3 Решение Андеррайтера
        element(l.section_anderrater).click()
        chose(l.reshenie_underrater, l.reshenie_underrater_val)
        element(l.button_next).click()
        element(l.button_finish).click()
