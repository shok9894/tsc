class allAttribut(object):
    list_attrib_file = open('list_attrib.txt')
