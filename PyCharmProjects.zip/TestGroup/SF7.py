from selenium.webdriver.support.wait import WebDriverWait
from data import *
from locators import *


class Page(object):
    def __init__(self, driver):
        self.driver = driver

    def fillform7(self):
        def chose(locator, value):
            try:
                self.driver.find_element_by_xpath(locator).click()
                self.driver.find_element_by_xpath(value).click()
            except Exception as err:
                print(err)

        def entr(locator, val):
            x = self.driver.find_element_by_xpath(locator)
            x.clear()
            x.send_keys(val)

        l = SF_7
        # d = data.SF7_Data
        # elements = self.driver.find_elements_by_xpath
        element = self.driver.find_element_by_xpath

        self.driver.find_element(*CommonLocators.rrr).click()
        self.driver.find_element(*CommonLocators.ChooseForm_07).click()
        try:
            WebDriverWait(self.driver, allData.wait_time).until(lambda x:
                                                                x.find_element(*CommonLocators.Verify_SF_07)
                                                                .is_displayed())
        except:
            print('Scren form don\'t load\n\033[31mTest failure!\033[0m')
            return False

        element(l.section_zam_dir).click()
        chose(l.reshenie, l.reshenie_val)
        element(l.button_next).click()
        try:
            WebDriverWait(self.driver, allData.wait_time).until(lambda x:
                                                                x.find_element_by_xpath(l.button_finish)
                                                                .is_displayed())
            element(l.button_finish).click()
        except:
            print('Scren form don\'t load or button finish is not displayed\n\033[31mTest failure!\033[0m')
            return False