import lxml.etree as Element
import lxml.html as html
from xml.etree import ElementTree
myxml = r'D:\XPath\my.xml'
xml = Element.parse(myxml)
list_sections = xml.xpath('//section')
for x in list_sections:
    print(x.attrib['name'])
list_attrib = xml.xpath('//list//*')

for x in list_attrib:
    print(x.text)
print('\n-------------------------------')

for x in list_attrib:
    path = xml.getpath(x)
    text = xml.xpath(path)[0].text
    print(path, str(text).strip('\n'))

tree = Element.Element('sections')
a = Element.Element('section')
a.text = 'First'
b = Element.SubElement(a, 'attrib')
b.text = 'Sub__'
tree.append(a)


#a = ET.ElementTree('sections')
#b = ElementTree.SubElement('section')
print(Element.tostring(tree, pretty_print=True))

