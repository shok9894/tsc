from data import allData
from selenium.webdriver.support.ui import WebDriverWait


# from locators import LoginPageLocators
# from selenium.webdriver.support import expected_conditions as EC


class BasePage(object):
    def __init__(self, driver):
        self.driver = driver


# class LoginPage(BasePage):
#         # Ожидаение загрузки страницы
#     def WaitPageShow(self):
#         # print("Wait for input login box is found")
#         WebDriverWait(self.driver, allData.wait_time).until(
#             EC.element_to_be_clickable((LoginPageLocators.InputLogin))
#         )
#
#     # Ввод логина
#     def typeLogin(self):
#         print("Enter login")
#         # WebDriverWait(self.driver, 10).until(
#         #   lambda driver: driver.find_element(*LoginPageLocators.InputLogin)
#         # )
#         self.driver.find_element(*LoginPageLocators.InputLogin).send_keys(*allData.login)
#
#     # Ввод пароля
#     def typePassword(self):
#         print("Enter password")
#         # WebDriverWait(self.driver, 10).until(
#         #   lambda driver: driver.find_element(*LoginPageLocators.InputPassword)
#         # )
#         self.driver.find_element(*LoginPageLocators.InputPassword).send_keys(*allData.password)
#
#     # Проверка загрузки страницы
#     def is_title_matches(self):
#         print('Open page: ', self.driver.title)
#         return allData.login_page_title in self.driver.title
#
#     # Нажатие на кнопку входа
#     def click_go_button(self):
#         print('Log-in on portal...')
#         self.driver.find_element(*LoginPageLocators.GO_BUTTON).click()


# class ResultLoginPage(BasePage):
#     def wait_page_load(self):
#
#         WebDriverWait(self.driver, allData.wait_time).until(
#             EC.element_to_be_clickable((CommonLocators.rrr))
#         )
#
#     def is_results_found(self):
#         print('Открыта страница', self.driver.title, 'а должна была быть', allData.base_page_title, sep=' - ')
#         if (allData.base_page_title in self.driver.title):
#             print('Login successful')
#             return True
#         else:
#             return False


class MainOperations(BasePage):
    def click_choose_form(self, form):
        self.driver.find_element(*form).click()

    def Wait_SF_load(self, screen):
        try:
            WebDriverWait(self.driver, allData.wait_time).until(lambda x: x.find_element(*screen).is_displayed())
        except:
            print('Scren form don\'t load\n\033[31mTest failure!\033[0m')
            return False

    def chose(self, locator, value):
        try:
            self.driver.find_element_by_xpath(locator).click()
            self.driver.find_element_by_xpath(value).click()
        except Exception as err:
            print(err)

    def entr(self, locator, val):
        self.driver.find_element_by_xpath(locator).location_once_scrolled_into_view
        x = self.driver.find_element_by_xpath(locator)
        x.clear()
        x.send_keys(val)

    def verify_atrib_contents(self):
        import SF_1_Data
        lis = [line.strip("\n") for line in SF_1_Data.allAttribut.list_attrib_file]
        SF_1_Data.allAttribut.list_attrib_file.close()
        base = self.driver.page_source
        for i in lis:
            print('Is attribut:\033[4m', i, '\033[0m on page? ', end='')
            if i in base:
                print('\033[32mTrue\033[0m')
            else:
                print('\033[31mFalse\033[0m')

# class Screen_form_1(BasePage):

#
#
#
#
#     # def fill_form_and_go(self):
#     #     try:
#     #         self.driver.find_element(*SF_1_Locators.Radio_Vr_Doc_Present).click()
#     #         self.driver.find_element(*SF_1_Locators.Radio_Quality_Scan).click()
#     #     except Exception as err:
#     #         print('I can\'t fill form\nTry go ahead')
#     #     try:
#     #         self.driver.find_element(*SF_1_Locators.Go_Button).click()
#     #     except Exception as err:
#     #         print('-' * 25, 'I can\'t click Go button', sep='\n')
#     #         raise Exception('I can\'t to do anything, Goodbye!')


# class ScreenFormRepeat(BasePage):
#
#     def screen_repeat(self):
#
#         # _________________________________________________________________
#         # Список форм
#         list_form = (
#             'Проверка комплектности и качества сканируемых основных документов Субъекта',
#             'Проверка комплектности и качества сканируемых дополнительных документов Субъекта',
#             'Проверка правильности ввода данных Субъекта'
#         )
#
#         # _________________________________________________________________
#         # Создание списка субъектов
#         list_subjects = [i.text for i in self.driver.find_elements_by_xpath(
#             '//div[@style="padding: 8px 0px; float: left; width: 15%;"]/div')]
#         YL, FL, IP = wsdl.subjects()
#
#         for x in YL + FL + IP:
#             print('Найден субъект', x) if x in list_subjects else print('Не найден субъект', x)
#
#         # _________________________________________________________________
#         # Начнинаем круг для N-го субъекта
#         for subject in list_subjects:
#             # _________________________________________________________________
#             # Круг для N формы
#             print('=' * 40, 'Start ', '=' * 40)
#             print('Начнинаем круг для субъекта:', subject)
#
#             if subject in IP:
#                 query_n = 2
#             elif subject in YL:
#                 query_n = 1
#             else:
#                 query_n = 0
#             # _________________________________________________________________
#             #  Цикл - костыль, потому что есть дефект названий 'сканирования(-уемых)'
#             for form in list_form:
#                 try:
#                     wait_obj = WebDriverWait(self.driver, 10).until(lambda x: x.find_element_by_xpath("//*[contains(text(),'%s')]" % form).is_displayed(), 'eeebbbbaaaa')
#                 except Exception as err:
#                     print(err)
#                     #raise err
#                 form = form.lower()
#                 try:
#                     actual_name_form = self.driver.find_element_by_xpath(
#                         '//div[@style="float: right; width: 85%;"]//div[@class="accordion_grey"]').text
#                     actual_name_form = actual_name_form.lower()
#                 except Exception as err:
#                     print(err)
#
#
#                 # Здесь просходит вырезание "сканируемых" и "сканирования" для сравнения названий
#                 if form == actual_name_form:
#                     # if (form.replace([x for x in list(form.split(' ')) if ('скан' in str(x))][0], '')) in \
#                     #         (actual_name_form.replace([x for x in list(actual_name_form.split(' ')) if ('скан' in str(x))][0], '')):
#
#                     print('Приступим к форме:', form, '\n', '=' * 80)
#                 else:
#                     print('Заголовок формы не совпал')
#
#                 # _________________________________________________________________
#                 #  Список секций, которые отображены на экранной форме
#                 try:
#                     obj_list_sections = self.driver.find_elements_by_xpath(
#                         '//div[@style="margin-left: 37px;"]//ancestor::div[contains(@class,"accordion_")]')
#                 except Exception as err:
#                     print('Что то пошло не так', err)
#                 # Создаю список из атрибутов объектов(секций),
#                 # в дальнейшем нужны два списка (объекты, названия секций)
#                 # list_section подмножество obj_list_section
#                 list_sections = obj_list_sections.copy()
#                 list_sections = [s.text for s in list_sections]
#
#                 # _________________________________________________________________
#                 # Списки секций, согласно базе данных
#                 if form == list_form[0].lower():
#                     query_list_group = [
#                         'select VALUE from REF_122_GROUP_DOC where level=2 START with VALUE=\'ФЛ\''
#                         ' CONNECT BY PRIOR INTERNALID=PARENTID',
#                         'select VALUE from REF_122_GROUP_DOC where level=2 START with VALUE=\'ЮЛ\''
#                         ' CONNECT BY PRIOR INTERNALID=PARENTID',
#                         'select VALUE from REF_122_GROUP_DOC where level=2 START with VALUE=\'ИП\''
#                         ' CONNECT BY PRIOR INTERNALID=PARENTID'
#                     ]
#                     query_list_doc = [
#                         "select * from (select * from REF_122_GROUP_DOC"
#                         "  START with VALUE='ФЛ'  "
#                         "CONNECT BY PRIOR INTERNALID=PARENTID) "
#                         "START with VALUE='%s'  "
#                         "CONNECT BY PRIOR INTERNALID=PARENTID",
#
#                         "select * from (select * from REF_122_GROUP_DOC"
#                         "  START with VALUE='ЮЛ'  "
#                         "CONNECT BY PRIOR INTERNALID=PARENTID) "
#                         "START with VALUE='%s'  "
#                         "CONNECT BY PRIOR INTERNALID=PARENTID",
#
#                         "select * from (select * from REF_122_GROUP_DOC"
#                         "  START with VALUE='ИП'  "
#                         "CONNECT BY PRIOR INTERNALID=PARENTID) "
#                         "START with VALUE='%s'  "
#                         "CONNECT BY PRIOR INTERNALID=PARENTID"
#                     ]
#                     # _________________________________________________________________
#                     # Подключение к базе
#                     try:
#                         conn = DataBaseConnect.connect_db()
#                         cursor = conn.cursor()
#                     except Exception as err:
#                         print('Ошибочка при подключении к базе:', err)
#                     # _________________________________________________________________
#                     # Выполнение запроса (выборки)
#                     try:
#                         # print(query_list[query_n])
#                         list_group = cursor.execute(query_list_group[query_n])
#                         list_group = list_group.fetchall()
#                         list_group = [i[0] for i in list_group]
#                         list_doc = {}
#                         for x in list_group:
#                             e = cursor.execute(query_list_doc[query_n] % x).fetchall()
#                             e = [i[3].upper() for i in e[1:]]
#                             list_doc.update({x.upper(): e})
#                         list_group = list(map(lambda x: x.upper(), list_group))
#
#                     except Exception as err:
#                         print('Ошибочка при выполнении выборки:', err)
#                     # _________________________________________________________________
#                     # Закрытие соединения с базой
#                     try:
#                         DataBaseConnect.connect_close(cursor=cursor, conn=conn)
#                     except Exception as err:
#                         print('Ошибочка при закрытии соединения с базой:', err)
#                     # _________________________________________________________________
#                     # Форматирование списка в формат как на ЭФ
#                     # list_group = [i[0].upper() for i in list_group]
#                     # _________________________________________________________________
#                     # Производится проверка состава секции
#                     # list_sections - список секций считаный с ЭФ
#                     # result - список секций согласно БД
#                     if set(list_group) ^ set(list_sections):
#                         if set(list_group) - set(list_sections):
#                             print('Не хватает секций\n',
#                                   str(set(list_group) - set(list_sections))
#                                   .replace(',', '\n')
#                                   .strip('{}'))
#                         if set(list_sections) - set(list_group):
#                             print('Лишнее\n',
#                                   str(set(list_sections) - set(list_group))
#                                   .replace(',', '\n')
#                                   .strip('{}'))
#                 # _________________________________________________________________
#                 # Обход и проверки в цикле
#                 n_sections = 0
#                 for section in list_sections:
#                     print('%d(%d) Зполняю секцию:' % (n_sections + 1, list_sections.__len__()), section,
#                           '\n', '-' * 100)
#                     # Проверка на открытость секции, и открытие в случае необходимости
#                     if form == list_form[0].lower():
#                         list_doc_on_sf = self.driver.find_elements_by_xpath("//div[@class='selectedAcc']//h4")
#                         list_doc_on_sf = [x.text.upper() for x in list_doc_on_sf]
#                         list_doc_on_sf = [x[x.find('.') + 2:] for x in list_doc_on_sf]
#                         # Не правильные названия секций на ЭФ ломают эти проверки
#                         #if set(list_doc[section]) ^ set(list_doc_on_sf):
#                         #    if set(list_doc[section]) - set(list_doc_on_sf):
#                         #        print('Не хватает документов\n',
#                         #              str(set(list_doc[section]) - set(list_doc_on_sf))
#                         #              .replace(", '", '\n\'')
#                         #              .strip('{}'), sep='')
#                         #    if set(list_doc_on_sf) - set(list_doc[section]):
#                         #        print('Лишние документы\n',
#                         #              str(set(list_doc_on_sf) - set(list_doc[section]))
#                         #              .replace(", '", '\n\'')
#                         #              .strip('{}'), sep=''
#                         #              )
#                     if 'accordion_white' == obj_list_sections[n_sections].get_attribute('class'):
#                         obj_list_sections[n_sections].click()
#                     # Проверка наличия блоков в секции
#                     list_bloks = self.driver.find_elements_by_xpath(
#                         '//div[@class="selectedAcc"]//div[contains(@class,"accordion_")]')
#                     if list_bloks.__len__() != 0:
#                         n_blok = 0
#                         if section == list_bloks[n_blok].text and list_bloks.__len__() < 2:
#                             pass
#                         else:
#                             for blok in list_bloks:
#                                 print('%d(%d).%d(%d) Заполняю блок:' % (n_sections + 1, list_sections.__len__(),
#                                                                         n_blok + 1, list_bloks.__len__()), blok.text,
#                                       '\n',
#                                       '-' * 100)
#                                 if 'accordion_white' in list_bloks[n_blok].get_attribute('class'):
#                                     blok.click()
#                                 n_blok += 1
#                                 list_yes_on_blok = self.driver.find_elements_by_xpath(
#                                     "//input[@name='YesNoFieldDiv' and @value='Yes']")
#                                 for yes in list_yes_on_blok:
#                                     yes.click()
#
#                     list_yes_on_section = self.driver.find_elements_by_xpath(
#                         "//input[@name='YesNoFieldDiv' and @value='Yes']")
#                     if list_yes_on_section:
#                         for yes in list_yes_on_section:
#                             yes.click()
#                     n_sections += 1
#                 print('=' * 120)
#                 try:
#                     self.driver.find_element_by_xpath(
#                         '//div[@style="padding-bottom: 8px;"]//*[contains(text(),\'Вперед\')]').click()
#                 except Exception as err:
#                     print('Тут при попытке нажать кнопку "ВПЕРЕД" возникла ошибка\n',
#                           err,
#                           '\nно, у меня есть мнение что это закончились проверки по субъектам.'
#                           '\nВ общем пробую пойти дальше :)')
#                     self.driver.find_element_by_xpath('//span[contains(text(),\'Вперед\')]').click()
#                     print('Да, точно, закончились проверки, по субъектам')
#
#                     # _________________________________________________________________
#                     # Конец
#
#         if self.driver.find_element_by_xpath('//span[contains(text(),\'Завершить задачу\')]'):
#             print('Текущая форма:', self.driver.find_element_by_xpath(
#                 '//div[@class="accordion_grey"]').text)
#             list_yes_on_section = self.driver.find_elements_by_xpath(
#                 "//input[@name='YesNoFieldDiv' and @value='Yes']")
#             for yes in list_yes_on_section:
#                 yes.click()
#             self.driver.find_element_by_xpath(
#                 '//span[contains(text(),\'Завершить задачу\')]').click()
#         return True





# class Screen_form_2(BasePage):
#     def fill_form2(self):
#         try:
#             actual_name_form = self.driver.find_element_by_xpath(
#                 '//div[@class="accordion_grey"]').text
#         except Exception as err:
#             print(err)
#         criterias = self.driver.find_elements_by_xpath('//div[@class="control-block"]/div[not(contains(@class,\'control-div-label\')) and position()=1]')
#         criterias = [x.text for x in criterias]
#         conn = DataBaseConnect.connect_db()
#         cursor = conn.cursor()
#         try:
#             list_criteria = cursor.execute('select VALUE from DAT_113_CR_TRUSTWORTHINESS').fetchall()
#             list_criteria = [x[0] for x in list_criteria]
#         except Exception as err:
#             print('Ошибочка при выполнении выборки:', err)
#         x = set(criterias)^set(list_criteria)
#         [print(i) for i in x if x]
#         DataBaseConnect.connect_close(cursor=cursor, conn=conn)
#         inputs = self.driver.find_elements_by_xpath("//div[@class='dropDownArea']")
#         inputs[0].click()
#         self.driver.find_element_by_xpath('//div[@class="dropDownMenu"]/div').click()
#         inputs[1].click()
#         self.driver.find_element_by_xpath('//div[@class="dropDownMenu"]/div[2]').click()
#         inputs[2].click()
#         self.driver.find_element_by_xpath('//div[@class="dropDownMenu"]/div[2]').click()
#         inputs[3].click()
#         self.driver.find_element_by_xpath('//div[@class="dropDownMenu"]/div').click()
#         self.driver.find_element_by_xpath(
#             '//span[contains(text(),\'Завершить задачу\')]').click()

# class Screen_form_3(BasePage):
#     def fill_form3(self):
#         list_subjects = self.driver.find_elements_by_xpath('//div[@style="padding: 8px 0px; float: left; width: 15%;"]/div')
#         list_subjects = [x.text for x in list_subjects]
#         list_form = [x+1 for x in range(8)]
#         for subject in list_subjects:
#             for x in list_form:
#                 list_yes_on_section = self.driver.find_elements_by_xpath(
#                     "//input[@name='YesNoFieldDiv' and @value='Yes']")
#                 for yes in list_yes_on_section:
#                     yes.click()
#                 try:
#                     self.driver.find_element_by_xpath("//span[text()='Вперед']").click()
#                 except Exception as err:
#                     print(err)
#                     try:
#                         self.driver.find_element_by_xpath("//span[text()='Завершить задачу']").click()
#                     except Exception as err:
#                         print('Ну просто полный FAIL', err)
