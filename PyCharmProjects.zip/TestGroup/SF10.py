from selenium.webdriver.support.wait import WebDriverWait
from data import *
from locators import *
from selenium.webdriver.support import expected_conditions as EC
import time

class Page(object):
    def __init__(self, driver):
        self.driver = driver

    def fillform10(self):
        def chose(locator, value):
            try:
                self.driver.find_element_by_xpath(locator).click()
                self.driver.find_element_by_xpath(value).click()
            except Exception as err:
                print(err)

        def entr(locator, val):
            x = self.driver.find_element_by_xpath(locator)
            x.clear()
            x.send_keys(val)

        l = SF_10
        # d = data.SF9_Data
        # elements = self.driver.find_elements_by_xpath
        element = self.driver.find_element_by_xpath

        self.driver.find_element(*CommonLocators.rrr).click()
        self.driver.find_element(*CommonLocators.ChooseForm_10).location_once_scrolled_into_view
        self.driver.find_element(*CommonLocators.ChooseForm_10).click()
        try:
            WebDriverWait(self.driver, allData.wait_time).until(
                lambda x:
                    x.find_element(*CommonLocators.Verify_SF_10)
                    .is_displayed()
                                                                )
        except Exception as err:
            print('Scren form don\'t load\n\033[31mTest failure!\033[0m')
            print(err)
            return False
        element(l.radio).click()
        element(l.button_finish).click()
