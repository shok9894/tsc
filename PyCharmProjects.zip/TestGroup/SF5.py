from selenium.webdriver.support.wait import WebDriverWait
from data import *
from locators import *



class Page(object):
    def __init__(self, driver):
        self.driver = driver

    def fillform5(self):
        def entr(locator, val):
            x = self.driver.find_element_by_xpath(locator)
            x.clear()
            x.send_keys(val)

        l = SF_5
        d = data.SF5_Data

        self.driver.find_element(*CommonLocators.rrr).click()
        self.driver.find_element(*CommonLocators.ChooseForm_05).click()
        try:
            WebDriverWait(self.driver, allData.wait_time).until(lambda x:
                                                                x.find_element(*CommonLocators.Verify_SF_05)
                                                                .is_displayed())
        except:
            print('Scren form don\'t load\n\033[31mTest failure!\033[0m')
            return False
        self.driver.find_element_by_xpath('//div[@class="contentBlock"]//div[1]//button').click()
        for x in self.driver.find_elements_by_xpath(l.section_stop_parametr):
            x.click()
        for x in self.driver.find_elements_by_xpath(l.stop_vivod):
            x.click()
            x.send_keys(d.text)
        for x in self.driver.find_elements_by_xpath(l.stop_vipolnenie_usloviy):
            x.click()
        entr(l.vivod, d.text)
        self.driver.find_element_by_xpath(l.button_next).click()

        try:
            WebDriverWait(self.driver, allData.wait_time).until(lambda x:
                                                                x.find_element_by_xpath(l.button_next)
                                                                .is_displayed())
        except Exception as err:
            print('Scren form don\'t load\n\033[31mTest failure!\033[0m')
            print(err)
            return err

        self.driver.find_element_by_xpath(l.button_next).click()
        try:
            WebDriverWait(self.driver, allData.wait_time).until(lambda x:
                                                                x.find_element_by_xpath(
                                                                    '//*[contains(text(),"Бухгалтерский баланс")]')
                                                                .is_displayed())
            self.driver.find_element_by_xpath(l.button_next).click()
            WebDriverWait(self.driver, allData.wait_time).until(lambda x:
                                                                x.find_element_by_xpath(
                                                                    '//*[contains(text(),"Бухгалтерский баланс")]')
                                                                .is_displayed())
        except Exception as err:
            print('Бухгалтерский баланс\n\033[31mTest failure!\033[0m')
            print(err)
            return err
        print('Бухгалтерский баланс')
        self.driver.find_element_by_xpath(l.button_next).click()

        try:
            WebDriverWait(self.driver, allData.wait_time).until(lambda x:
                                                                x.find_element_by_xpath(
                                                                    '//div[contains(text(),"Отчет о финансовых резул")]')
                                                                .is_displayed())
        except Exception as err:
            print('Отчет о финансовых результатах\n\033[31mTest failure!\033[0m')
            print(err)
            return False
        print('Отчет о финансовых результатах - Форма по ОКУД 0710002')
        self.driver.find_element_by_xpath(l.button_next).click()
        try:
            WebDriverWait(self.driver, allData.wait_time).until(lambda x:
                                                                x.find_element_by_xpath(
                                                                    '//*[contains(text(),"Дата истечения срока")]')
                                                                .is_displayed())
        except Exception as err:
            print('Проект решения\n\033[31mTest failure!\033[0m')
            print(err)
            return err
        print('Проект решения')
        self.driver.find_element_by_xpath(l.section_KA).click()
        self.driver.find_element_by_xpath(l.KA_reshenie).click()
        self.driver.find_element_by_xpath(l.KA_reshenie_true).click()
        self.driver.find_element_by_xpath(l.button_next).click()
        try:
            WebDriverWait(self.driver, allData.wait_time).until(lambda x:
                                                                x.find_element_by_xpath(
                                                                    '//span[text()="Завершить задачу"]')
                                                                .is_displayed())
        except Exception as err:
            print('Протокол решения КА\n\033[31mTest failure!\033[0m')
            print(err)
            return err
        self.driver.find_element_by_xpath('//span[text()="Завершить задачу"]').click()
