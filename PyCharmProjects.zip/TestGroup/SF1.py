from data import *
from locators import SF_1
from selenium.webdriver.support.ui import WebDriverWait
import DataBaseConnect
import wsdl

class Page(object):
    def __init__(self, driver):
        self.driver = driver

    def fillform1(self):
        element = self.driver.find_element_by_xpath
        elements = self.driver.find_elements_by_xpath
        try:
            element(SF_1.Radio_Vr_Doc_Present).click()
            element(SF_1.Radio_Quality_Scan).click()
        except Exception as err:
            print('I can\'t fill form\nTry go ahead')
        try:
            element(SF_1.Go_Button).click()
        except Exception as err:
            print('-' * 25, 'I can\'t click Go button', sep='\n')
            raise Exception('I can\'t to do anything, Goodbye!')
        # _________________________________________________________________
        # Список форм
        list_form = (
            'Проверка комплектности и качества сканируемых основных документов Субъекта',
            'Проверка комплектности и качества сканируемых дополнительных документов Субъекта',
            'Проверка правильности ввода данных Субъекта'
        )

        # _________________________________________________________________
        # Создание списка субъектов
        list_subjects = [i.text for i in elements(
            SF_1.list_subjects)]
        YL, FL, IP = wsdl.subjects()

        for x in YL + FL + IP:
            print('Найден субъект', x) if x in list_subjects else print('Не найден субъект', x)

        # _________________________________________________________________
        # Начнинаем круг для N-го субъекта
        for subject in list_subjects:
            # _________________________________________________________________
            # Круг для N формы
            print('=' * 40, 'Start ', '=' * 40)
            print('Начнинаем круг для субъекта:', subject)

            if subject in IP:
                query_n = 2
            elif subject in YL:
                query_n = 1
            else:
                query_n = 0
            # _________________________________________________________________
            #  Цикл - костыль, потому что есть дефект названий 'сканирования(-уемых)'
            for form in list_form:
                try:
                    WebDriverWait(self.driver, allData.wait_time).until(
                        lambda x: x.find_element_by_xpath("//*[contains(text(),'%s')]" % form).is_displayed(),
                        'Ogo-go')
                except Exception as err:
                    print(err)
                    # raise err
                form = form.lower()
                try:
                    actual_name_form = element(SF_1.actual_name_form).text
                    actual_name_form = actual_name_form.lower()
                except Exception as err:
                    print(err)

                # Здесь просходит вырезание "сканируемых" и "сканирования" для сравнения названий
                if form == actual_name_form:
                    # if (form.replace([x for x in list(form.split(' ')) if ('скан' in str(x))][0], '')) in \
                    #         (actual_name_form.replace([x for x in list(actual_name_form.split(' ')) if ('скан' in str(x))][0], '')):

                    print('Приступим к форме:', form, '\n', '=' * 80)
                else:
                    print('Заголовок формы не совпал')

                # _________________________________________________________________
                #  Список секций, которые отображены на экранной форме
                try:
                    obj_list_sections = elements(
                        SF_1.obj_list_sections)
                except Exception as err:
                    print('Что то пошло не так', err)
                # Создаю список из атрибутов объектов(секций),
                # в дальнейшем нужны два списка (объекты, названия секций)
                # list_section подмножество obj_list_section
                list_sections = obj_list_sections.copy()
                list_sections = [s.text for s in list_sections]

                # _________________________________________________________________
                # Списки секций, согласно базе данных
                if form == list_form[0].lower():
                    query_list_group = [
                        'select VALUE from REF_122_GROUP_DOC where level=2 START with VALUE=\'ФЛ\''
                        ' CONNECT BY PRIOR INTERNALID=PARENTID',
                        'select VALUE from REF_122_GROUP_DOC where level=2 START with VALUE=\'ЮЛ\''
                        ' CONNECT BY PRIOR INTERNALID=PARENTID',
                        'select VALUE from REF_122_GROUP_DOC where level=2 START with VALUE=\'ИП\''
                        ' CONNECT BY PRIOR INTERNALID=PARENTID'
                    ]
                    query_list_doc = [
                        "select * from (select * from REF_122_GROUP_DOC"
                        "  START with VALUE='ФЛ'  "
                        "CONNECT BY PRIOR INTERNALID=PARENTID) "
                        "START with VALUE='%s'  "
                        "CONNECT BY PRIOR INTERNALID=PARENTID",

                        "select * from (select * from REF_122_GROUP_DOC"
                        "  START with VALUE='ЮЛ'  "
                        "CONNECT BY PRIOR INTERNALID=PARENTID) "
                        "START with VALUE='%s'  "
                        "CONNECT BY PRIOR INTERNALID=PARENTID",

                        "select * from (select * from REF_122_GROUP_DOC"
                        "  START with VALUE='ИП'  "
                        "CONNECT BY PRIOR INTERNALID=PARENTID) "
                        "START with VALUE='%s'  "
                        "CONNECT BY PRIOR INTERNALID=PARENTID"
                    ]
                    # _________________________________________________________________
                    # Подключение к базе
                    try:
                        conn = DataBaseConnect.connect_db()
                        cursor = conn.cursor()
                    except Exception as err:
                        print('Ошибочка при подключении к базе:', err)
                    # _________________________________________________________________
                    # Выполнение запроса (выборки)
                    try:
                        # print(query_list[query_n])
                        list_group = cursor.execute(query_list_group[query_n])
                        list_group = list_group.fetchall()
                        list_group = [i[0] for i in list_group]
                        list_doc = {}
                        for x in list_group:
                            e = cursor.execute(query_list_doc[query_n] % x).fetchall()
                            e = [i[3].upper() for i in e[1:]]
                            list_doc.update({x.upper(): e})
                        list_group = list(map(lambda x: x.upper(), list_group))

                    except Exception as err:
                        print('Ошибочка при выполнении выборки:', err)
                    # _________________________________________________________________
                    # Закрытие соединения с базой
                    try:
                        DataBaseConnect.connect_close(cursor=cursor, conn=conn)
                    except Exception as err:
                        print('Ошибочка при закрытии соединения с базой:', err)
                    # _________________________________________________________________
                    # Форматирование списка в формат как на ЭФ
                    # list_group = [i[0].upper() for i in list_group]
                    # _________________________________________________________________
                    # Производится проверка состава секции
                    # list_sections - список секций считаный с ЭФ
                    # result - список секций согласно БД
                    if set(list_group) ^ set(list_sections):
                        if set(list_group) - set(list_sections):
                            print('Не хватает секций\n',
                                  str(set(list_group) - set(list_sections))
                                  .replace(',', '\n')
                                  .strip('{}'))
                        if set(list_sections) - set(list_group):
                            print('Лишнее\n',
                                  str(set(list_sections) - set(list_group))
                                  .replace(',', '\n')
                                  .strip('{}'))
                # _________________________________________________________________
                # Обход и проверки в цикле
                n_sections = 0
                for section in list_sections:
                    print('%d(%d) Зполняю секцию:' % (n_sections + 1, list_sections.__len__()), section,
                          '\n', '-' * 100)
                    # Проверка на открытость секции, и открытие в случае необходимости
                    if form == list_form[0].lower():
                        list_doc_on_sf = elements(SF_1.list_doc_on_sf)
                        list_doc_on_sf = [x.text.upper() for x in list_doc_on_sf]
                        list_doc_on_sf = [x[x.find('.') + 2:] for x in list_doc_on_sf]
                        # Не правильные названия секций на ЭФ ломают эти проверки
                        # if set(list_doc[section]) ^ set(list_doc_on_sf):
                        #    if set(list_doc[section]) - set(list_doc_on_sf):
                        #        print('Не хватает документов\n',
                        #              str(set(list_doc[section]) - set(list_doc_on_sf))
                        #              .replace(", '", '\n\'')
                        #              .strip('{}'), sep='')
                        #    if set(list_doc_on_sf) - set(list_doc[section]):
                        #        print('Лишние документы\n',
                        #              str(set(list_doc_on_sf) - set(list_doc[section]))
                        #              .replace(", '", '\n\'')
                        #              .strip('{}'), sep=''
                        #              )
                    if 'accordion_white' == obj_list_sections[n_sections].get_attribute('class'):
                        obj_list_sections[n_sections].click()
                    # Проверка наличия блоков в секции
                    list_bloks = elements(SF_1.list_bloks)
                    if list_bloks.__len__() != 0:
                        n_blok = 0
                        if section == list_bloks[n_blok].text and list_bloks.__len__() < 2:
                            pass
                        else:
                            for blok in list_bloks:
                                print('%d(%d).%d(%d) Заполняю блок:' % (n_sections + 1, list_sections.__len__(),
                                                                        n_blok + 1, list_bloks.__len__()),
                                      blok.text,
                                      '\n',
                                      '-' * 100)
                                if 'accordion_white' in list_bloks[n_blok].get_attribute('class'):
                                    blok.click()
                                n_blok += 1
                                list_yes_on_blok = elements(SF_1.list_yes)
                                for yes in list_yes_on_blok:
                                    yes.click()

                    list_yes_on_section = elements(SF_1.list_yes)
                    if list_yes_on_section:
                        for yes in list_yes_on_section:
                            yes.click()
                    n_sections += 1
                print('=' * 120)
                try:
                    element(SF_1.Go_Button_in_Master).click()
                except Exception as err:
                    print('Тут при попытке нажать кнопку "ВПЕРЕД" возникла ошибка\n',
                          err,
                          '\nно, у меня есть мнение что это закончились проверки по субъектам.'
                          '\nВ общем пробую пойти дальше :)')
                    element(SF_1.button_next).click()
                    print('Да, точно, закончились проверки, по субъектам')

                    # _________________________________________________________________
                    # Конец

        if element(SF_1.button_finish):
            print('Текущая форма:', element(
                '//div[@class="accordion_grey"]').text)
            list_yes_on_section = elements(
                SF_1.list_yes)
            for yes in list_yes_on_section:
                yes.click()
                element(SF_1.button_finish).click()
        return True
