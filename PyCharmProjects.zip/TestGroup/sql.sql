select t.point,t.date,t.inc,tt.out from
  (select ad1.point,ad1.date,out from outcome_o o
    full join
      ( select point,date from income_o
        union
        select point,date from outcome_o
      ) ad1
    ON o.date = ad1.date and o.point = ad1.point) tt
full join
  (select ad2.point,ad2.date,inc from income_o i
    full join
      ( select point,date from income_o
        union
        select point,date from outcome_o
      ) ad2
    ON i.date=ad2.date and i.point=ad2.point) t
on t.point=tt.point and t.date=tt.date


select point,date,sum(out) out from
 (select ad1.point,ad1.date,out from outcome o
    full join
      ( select point,date from income
        union
        select point,date from outcome
      ) ad1
    ON o.date = ad1.date and o.point = ad1.point) x
group by point,date

select t.point,t.date,t.inc,tt.out from
  (
    select point,date,sum(out) out from
     (
      select ad1.point,ad1.date,out from outcome o
        full join
          (
            select point,date from income
            union
            select point,date from outcome
          ) ad1
        ON o.date = ad1.date and o.point = ad1.point
      ) x
  group by point,date
  ) tt
full join
  (
   select point,date,sum(inc) inc from
     (
      select ad1.point,ad1.date,inc from income i
        full join
          (
            select point,date from income
            union
            select point,date from outcome
          ) ad1
        ON i.date = ad1.date and i.point = ad1.point
      ) x
  group by point,date
   ) t
on t.point=tt.point and t.date=tt.date