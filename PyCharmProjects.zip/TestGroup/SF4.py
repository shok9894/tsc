from selenium.webdriver.support.wait import WebDriverWait
from data import *
from locators import *
import datetime
import page


# import SF4  # locators


class Page(object):
    def __init__(self, driver):
        self.driver = driver

    def fillform4(self):
        # def entr(locator, val):
        #     x = self.driver.find_element_by_xpath(locator)
        #     x.clear()
        #     x.send_keys(val)
        entr = page.MainOperations.entr
        chose = page.MainOperations.chose
        locator = SF_4
        dat = data.SF4_Data
        radio = self.driver.find_element_by_xpath
        element = self.driver.find_element_by_xpath
        elements = self.driver.find_elements_by_xpath

        # self.driver.find_element(*CommonLocators.rrr).click()
        # self.driver.find_element(*CommonLocators.ChooseForm_04).click()
        try:
            WebDriverWait(self.driver, allData.wait_time).until(lambda x:
                                                                x.find_element(*CommonLocators.Verify_SF_04)
                                                                .is_displayed())
        except:
            print('Scren form don\'t load\n\033[31mTest failure!\033[0m')
            return False
            element('//div[@class="contentBlock"]//div[3]//button').click()
        # Variables
        # --------------------------------------------------------------------------------------------

        # --------------------------------------------------------------------------------------------
        print('Описание бизнеса')
        entr(self, locator.chislo_polnix_let_osnovnogo_sobstvenika, dat.chislo_polnix_let_osnovnogo_sobstvenika)
        entr(self, locator.chislo_polnix_let_raboti_Zaemshika, dat.chislo_polnix_let_raboti_Zaemshika)
        entr(self, locator.data_pervogo_postupleniya_viruchki, dat.data_pervogo_postupleniya_viruchki)
        entr(self, locator.kolichestvo_rabotneykov_Subekta, dat.kolichestvo_rabotneykov_Subekta)
        entr(self, locator.fizicheskii_pokazatel_declariruemoe, dat.fizicheskii_pokazatel_declariruemoe)
        entr(self, locator.fizicheskii_pokazatel_fakticheskoe, dat.fizicheskii_pokazatel_fakticheskoe)
        if element(locator.section_kontragenti_Zaemshika) \
                .get_attribute('class') == 'accordion_white':
            element(locator.section_kontragenti_Zaemshika).click()
        entr(self, locator.postavshik_kolichestvo, dat.postavshik_kolichestvo)
        entr(self, locator.postavshik_dolia_krupneishego_kontragenta, dat.pokupateli_dolia_krupneishego_kontragenta)
        entr(self, locator.pokupateli_kolichestvo, dat.pokupateli_kolichestvo)
        entr(self, locator.pokupateli_dolia_krupneishego_kontragenta, dat.pokupateli_dolia_krupneishego_kontragenta)
        if element(locator.section_obyazatelstva) \
                .get_attribute('class') == 'accordion_white':
            element(locator.section_obyazatelstva).click()
        entr(self, locator.obyazatelstva_credit_cards, dat.empty)
        entr(self, locator.obyazatelstva_potrebitelskie_credits, dat.empty)
        entr(self, locator.obyazatelstva_Kredity_na_priobretenie_transportnyh_sredstv, dat.empty)
        entr(self, locator.obyazatelstva_Kredity_na_priobretenie_nedvizhimosti, dat.empty)
        if element(locator.section_dopolnitelno_for_apk) \
                .get_attribute('class') == 'accordion_white':
            element(locator.section_dopolnitelno_for_apk).click()
        entr(self, locator.apk_Dannie_o_straxovanii_zaemshikom_selskohozyastvennix_riskov,
             dat.apk_dannye_o_strahovanii_Zaemshchikom_selsko_xozyaistvennyx_riskov)
        entr(self, locator.apk_Dannie_o_nalichii_v_shtate_neobhodimyh_profilnyh_specialistov,
             dat.apk_dannye_o_nalichii_v_shtate_neobhodimyh_profilnyx_specialistow)
        if element(locator.section_spravka_o_resultatah_viezda) \
                .get_attribute('class') == 'accordion_white':
            element(locator.section_spravka_o_resultatah_viezda).click()
        for x in elements(locator.spravka_informaciya_o_businese):
            x.clear()
            x.send_keys(dat.informaciya_o_biznese)
        for x in elements(locator.spravka_sootvetstsvie_zayavlennoi_clientom_info):
            x.click()
            element(locator.button_next).click()
        print("Даты и периоды")
        try:
            WebDriverWait(self.driver, allData.wait_time) \
                .until(lambda x:
                       x.find_element_by_xpath("//td[contains(text(),'Дата 2')]")
                       .is_displayed())
        except:
            print('Scren form don\'t load\n\033[31mTest failure!\033[0m')
            return False
        date = [int(x) for x in str(
            element("//td[contains(text(),'Дата 1')]/following-sibling::td[1]").text).split('.')]
        date.reverse()
        date = datetime.datetime(date[0] + 1, 4, date[2])
        entr(self, locator.date_2_balance, date.strftime('%d.%m.%Y'))
        element(locator.button_next).click()
        print("Дата 1 баланс")
        try:
            WebDriverWait(self.driver, allData.wait_time) \
                .until(lambda x:
                       x.find_element_by_xpath(locator.active_zdaniia_i_sooruzheniia)
                       .is_displayed())
        except:
            print('Scren form don\'t load\n\033[31mTest failure!\033[0m')
            return False
        for x in elements(locator.date_1_inputs):
            x.clear()
            x.send_keys(dat.zero)
        entr(self, locator.active_denezhnye_sredstva_na_schetax, dat.active_denezhnye_sredstva_na_schetax)
        entr(self, locator.active_denezhnye_sredstva_v_kasse, dat.active_denezhnye_sredstva_v_kasse)
        entr(self, locator.active_tovary, dat.active_tovary)
        entr(self, locator.active_zdaniia_i_sooruzheniia, dat.active_zdaniia_i_sooruzheniia)
        entr(self, locator.passive_dolgosrochnye_kredity, dat.passive_dolgosrochnye_kredity)
        entr(self, locator.passive_kratkosrochnye_kredity, dat.passive_kratkosrochnye_kredity)
        entr(self, locator.passive_nakoplennyi_kapital, dat.passive_nakoplennyi_kapital)
        element(locator.button_next).click()
        print("Дата 2 баланс")
        try:
            WebDriverWait(self.driver, allData.wait_time) \
                .until(lambda x:
                       x.find_element_by_xpath(locator.pp_active_zdaniia_i_sooruzheniia)
                       .is_displayed())
        except:
            print('Scren form don\'t load\n\033[31mTest failure!\033[0m')
            return False
        for x in elements("//table[.//*[text()='Наименование статьи']]//input[@type='text']"):
            x.clear()
            x.send_keys(dat.zero)
        entr(self, locator.pp_active_denezhnye_sredstva_na_schetax, dat.active_denezhnye_sredstva_na_schetax)
        entr(self, locator.p3_active_denezhnye_sredstva_na_schetax, dat.active_denezhnye_sredstva_na_schetax)
        entr(self, locator.pp_active_denezhnye_sredstva_v_kasse, dat.active_denezhnye_sredstva_v_kasse)
        entr(self, locator.p3_active_denezhnye_sredstva_v_kasse, dat.active_denezhnye_sredstva_v_kasse)
        entr(self, locator.pp_active_tovary, dat.active_tovary)
        entr(self, locator.p3_active_tovary, dat.active_tovary)
        entr(self, locator.pp_active_zdaniia_i_sooruzheniia, dat.active_zdaniia_i_sooruzheniia)
        entr(self, locator.p3_active_zdaniia_i_sooruzheniia, dat.active_zdaniia_i_sooruzheniia)
        entr(self, locator.pp_passive_dolgosrochnye_kredity, dat.passive_dolgosrochnye_kredity)
        entr(self, locator.p3_passive_dolgosrochnye_kredity, dat.passive_dolgosrochnye_kredity)
        entr(self, locator.pp_passive_kratkosrochnye_kredity, dat.passive_kratkosrochnye_kredity)
        entr(self, locator.p3_passive_kratkosrochnye_kredity, dat.passive_kratkosrochnye_kredity)
        entr(self, locator.pp_passive_nakoplennyi_kapital, dat.passive_nakoplennyi_kapital)
        entr(self, locator.p3_passive_nakoplennyi_kapital, dat.passive_nakoplennyi_kapital)
        element(locator.button_next).click()
        print("Дата 3 баланс")
        try:
            WebDriverWait(self.driver, allData.wait_time) \
                .until(lambda x:
                       x.find_element_by_xpath(locator.pp_dat3_active_tovary)
                       .is_displayed())
        except:
            print('Scren form don\'t load\n\033[31mTest failure!\033[0m')
            return False
        for x in elements("//table[.//*[text()='Наименование статьи']]//input[@type='text']"):
            x.clear()
            x.send_keys(dat.zero)
        entr(self, locator.pp_dat3_active_denezhnye_sredstva_na_schetax, dat.active_denezhnye_sredstva_na_schetax)
        entr(self, locator.pp_dat3_active_denezhnye_sredstva_v_kasse, dat.active_denezhnye_sredstva_v_kasse)
        entr(self, locator.pp_dat3_active_tovary, dat.active_tovary)
        entr(self, locator.pp_dat3_active_zdaniia_i_sooruzheniia, dat.active_zdaniia_i_sooruzheniia)
        entr(self, locator.pp_dat3_passive_dolgosrochnye_kredity, dat.passive_dolgosrochnye_kredity)
        entr(self, locator.pp_dat3_passive_kratkosrochnye_kredity, dat.passive_kratkosrochnye_kredity)
        entr(self, locator.pp_dat3_passive_nakoplennyi_kapital, dat.passive_nakoplennyi_kapital)
        element(locator.button_next).click()
        print('ОПиУ')
        try:
            WebDriverWait(self.driver, allData.wait_time) \
                .until(lambda x:
                       x.find_element_by_xpath(locator.viruchka_ot_prodajy_tovara1)
                       .is_displayed())
        except:
            print('1\n\033[31mTest failure!\033[0m')
            return False
        ii = 0
        while True:
            try:
                WebDriverWait(self.driver, allData.wait_time) \
                    .until(lambda x:
                           x.find_element_by_xpath(locator.viruchka_ot_prodajy_tovara1)
                           .is_displayed())
            except:
                print('Не найдена выручка от продажи товара 1\n\033[31mTest failure!\033[0m')
                with open('Failed_page_source.html', 'w', encoding='UTF-8') as f:
                    f.write(self.driver.page_source)
                    break

            entr(self, locator.viruchka_ot_prodajy_tovara1, dat.viruchka_ot_prodajy_tovara1)
            entr(self, locator.prochie_doxody, dat.prochie_doxody)
            # entr(l.sebestoimost_tovara1, d.sebestoimost_tovara1)
            entr(self, locator.nacenka_po_tovary1, dat.nacenka_po_tovary1)
            entr(self, locator.arenda_komunalnye_platezi, dat.arenda_komunalnye_platezi)
            entr(self, locator.zarplata_s_nachisleniyami, dat.zarplata_s_nachisleniyami)
            entr(self, locator.transportnie_rasxody, dat.transportnie_rasxody)
            entr(self, locator.uslugi_banka_i_svyazy, dat.uslugi_banka_i_svyazy)
            # entr(l.prochie_postoyannie_rasxody,d.prochie_postoyannie_rasxody)
            entr(self, locator.pogashenie_dolga_v_RSHB, dat.pogashenie_dolga_v_RSHB)
            if ii > 14:
                print('Ой усталл...')
                return False

            ii += 1
            try:
                element(locator.zona_otvetstvennosti).is_displayed()
                entr(self, locator.zona_otvetstvennosti, dat.zona_otvetstvennosti)
                break
            except:
                pass
            finally:
                element(locator.button_next).click()

        # Расшифровка финансовой информации
        print('Расшифровка финансовой информации')
        try:
            WebDriverWait(self.driver, allData.wait_time) \
                .until(lambda x:
                       x.find_element_by_xpath(locator.dlytelnost_kartoteki)
                       .is_displayed())
        except:
            print('Scren form don\'t load\n\033[31mTest failure!\033[0m')
            return False
        entr(self, locator.dlytelnost_kartoteki, dat.dlytelnost_kartoteki)
        element(locator.section_dynamica_viruchki_i_oborotov).click()
        for x in elements(locator.viruchka):
            x.click()
            x.send_keys(dat.viruchka)
        for x in elements(locator.pribl_ubytok):
            x.click()
            x.send_keys(dat.pribl_ubytok)
        for x in elements(locator.oboroty_po_rs):
            x.click()
            x.send_keys(dat.oboroty_po_rs)
            element(locator.section_otchet_o_pribyli_i_ubytkah).click()
        entr(self, locator.sredniaia_vyruchka_dlya_celei_opredeleniya_potentciala,
             dat.sredniaia_vyruchka_dlya_celei_opredeleniya_potentciala)
        for x in elements(locator.viruchka_po_dannim_offical_otchetnosti):
            x.click()
            x.send_keys(dat.viruchka_po_dannim_offical_otchetnosti)
        for x in elements(locator.pribl_ubytok_po_dannim_offical_otchetnosti):
            x.click()
            x.send_keys(dat.pribl_ubytok_po_dannim_offical_otchetnosti)
            element(locator.section_lizingovye_obyazatelstva).click()
        entr(self, locator.ostatok_lizingovyh_obyazatelstv, dat.zero)
        entr(self, locator.summa_tekushix_lizingoyh_obyazatelstv, dat.zero)
        element(locator.nalichie_skityx_poter).click()
        element(locator.button_next).click()
        try:
            WebDriverWait(self.driver, allData.wait_time) \
                .until(lambda x:
                       x.find_element_by_xpath(locator.section_common_info)
                       .is_displayed())
        except:
            print('Общая информация\033[31m не загружена!\033[0m')
            return False

        if element(locator.section_common_info).get_attribute('class') == 'accordion_white':
            element(locator.section_common_info).click()
        # element(l.section_common_info).click()
            element(locator.section_analyz_izmeneniya_sobstvennogo_kapitala).click()
        entr(self, locator.credit_level_prinyatiya_resheniya, dat.credit_level_prinyatiya_resheniya)
        entr(self, locator.sobstvenniy_kapital_na_Data_2, dat.sobstvennyi_kapital_na_Data_2)
        entr(self, locator.sobstvenniy_kapital_na_Data_3, dat.sobstvennyi_kapital_na_Data_3)
        entr(self, locator.nakoplennaya_chistaya_prybl, dat.nakoplennaya_chistaya_pribyl)
        element(locator.button_next).click()
        pass

        # Добавить ожидание
        # def chose(locator, value):
        #     try:
        #         element(locator).click()
        #         element(value).click()
        #     except Exception as err:
        #         print(err)


        print("Нефинансовые факторы")
        chose(self, locator.b1_field, locator.b1)
        chose(self, locator.b2_field, locator.b2)
        chose(self, locator.b3_field, locator.b3)
        chose(self, locator.b4_field, locator.b4)
        chose(self, locator.b5_field, locator.b5)
        chose(self, locator.b6_field, locator.b6)
        chose(self, locator.b7_field, locator.b7)
        chose(self, locator.b8_field, locator.b8)
        chose(self, locator.b9_field, locator.b9)
        radio(locator.b10_field).click()
        entr(self, locator.b11_field, dat.b11)
        chose(self, locator.b12_field, locator.b12)
        radio(locator.b13_field).click()
        # radio(l.b14_field).click()
        # radio(l.b15_field).click()
        entr(self, locator.b16_field, dat.b16)
        chose(self, locator.b17_field, locator.b17)
        # radio(l.b18_field).click()
        chose(self, locator.b19_field, locator.b19)
        # entr(self, l.b20_field, d.b20)
        # entr(self, l.b21_field, d.b21)
        # entr(self, l.b22_field, d.b22)
        # entr(self, l.b23_field, d.b23)
        # entr(self, l.b24_field, d.b24)
        chose(self, locator.b25_field, locator.b25)
        radio(locator.b26_field).click()
        radio(locator.b27_field).click()
        entr(self, locator.b28_field, dat.b28)
        radio(locator.b29_field).click()
        # chose(self, l.b30_field, d.b30).click()
        chose(self, locator.b31_field, locator.b31)
        element(locator.button_next).click()
        print('Предупреждающие сигналы')
        try:
            WebDriverWait(self.driver, allData.wait_time) \
                .until(lambda x:
                       x.find_element_by_xpath(locator.c3_field)
                       .is_displayed())
        except:
            print('Предупреждающие сигналы\033[31m не загружена!\033[0m')
        for x in elements(locator.c_list_yes):
            x.click()
        chose(self, locator.c3_field, locator.c3)
        chose(self, locator.c4_field, locator.c4)
        chose(self, locator.c12_field, locator.c12)
        chose(self, locator.c13_field, locator.c13)
        chose(self, locator.c14_field, locator.c14)
        entr(self, locator.c16_field, dat.c16)
        element(locator.button_next).click()
        try:
            WebDriverWait(self.driver, allData.wait_time) \
                .until(lambda x:
                       x.find_element_by_xpath(locator.button_finish)
                       .is_displayed())
        except:
            print('Предупреждающие сигналы\033[31m не загружена!\033[0m')
            element(locator.button_finish).click()
