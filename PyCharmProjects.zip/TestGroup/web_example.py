from http.server import HTTPServer, CGIHTTPRequestHandler

try:
    print('Press Ctrl+С to exit')
    while True:
        server_address = ('', 8000)
        httpd = HTTPServer(server_address, CGIHTTPRequestHandler)
        httpd.serve_forever()

except KeyboardInterrupt:
    pass
