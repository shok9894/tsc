import cx_Oracle as cx
import os

kkr_micro = 'SME_REF_DEV/SME_REF_DEV@dedgetsc4.dedic.renter.ru:1521/BPM8'
ispz = 'RSHB_PZ_BPM_TEST/RSHB_PZ_BPM_TEST@bcvm187:1521/BPM8'

def connect_db():
    os.environ['NLS_LANG'] = 'American_America.AL32UTF8'
    con = cx.connect('SME_REF_DEV/SME_REF_DEV@dedgetsc4.dedic.renter.ru:1521/BPM8')
    return con
'''
result = cursor.execute('select * from REF_097_CR_DOC_COMPLETENESS_AP')
list_result = list()

for r in result:
    list_result.append(list(r))
sort_list = list()
for raw in list_result:
    sort_list.append(raw[3])
    print(raw[3])
'''
#print(str(sort_list).replace(', ', '\n').strip('[]'))
def connect_close(conn,cursor):

    cursor.close()
    conn.close()

def connect_db_string(connection_string):
    os.environ['NLS_LANG'] = 'American_America.AL32UTF8'
    con = cx.connect(connection_string)
    return con

#print(str(sort_list).replace(', ', '\n').strip('[]'))
def connect_close_string(conn, cursor):

    cursor.close()
    conn.close()

connction = connect_db_string(ispz)
cursor = connction.cursor()
instanceId = 1222606
query = 'select PARENTPROCESSINSTANCEID from PROCESSINSTANCELOG where PROCESSINSTANCEID = %s' % instanceId
result = cursor.execute(query)
list_result = list()
print('-'*80)
[print(x[0], end=' - ') for x in result.description]
print()
print('-'*80)
spis = []
for row in result.fetchall():
    print(row[0])
    spis.append(row[0])
print('-'*80)
lis = []
go = 'select PROCESSINSTANCEID from PROCESSINSTANCELOG where PARENTPROCESSINSTANCEID = %s'
if str(result.fetchvars[0].values[0]) == '-1':
    instanceId2 = instanceId
else:
    instanceId2 = result.fetchvars[0].values[0]

result2 = cursor.execute(go % instanceId2)
for r in result2.fetchvars[0].values:
    cursor.execute(go % r)
    lis.append()


# for r in result:
#     list_result.append(list(r))
# sort_list = list()
# for raw in list_result:
#     sort_list.append(raw[3])
#     print(raw[3])
