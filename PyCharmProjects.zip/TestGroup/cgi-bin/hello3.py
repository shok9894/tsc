import requests
import requests.auth
import lxml.etree as ET
from requests import auth
import sys

proxies = {'http': 'http://isizov:shok9894@proxy.tsc.ts:8080/'}
print("Content-type: text/xml")
print()

def get_info(instanceId):
    res = requests.get((
            'http://bcvm635.tsc.ts:8080/kie-server/services/rest/server/queries/processes/instances/%s?withVars=True' % instanceId),
        proxies=proxies, auth=auth.HTTPBasicAuth('bpm_rest', 'bpm_rest'))

    info = ET.fromstring(res.text.encode())

    return info.xpath(
        '//active-user-tasks|' +
        '//entry[./key[text()="IN_currentRef"]]|' +
        '//entry[./key[text()="IN_clientFullName"]]|' +
        '//entry[./key[text()="IN_taskRefId"]]'
    )


def instance(parents=['-1']):
    res = requests.get(
        'http://bcvm635.tsc.ts:8080/kie-server/services/rest/server/queries/processes/instances?pageSize=9999999&page=0',
        proxies=proxies, auth=auth.HTTPBasicAuth('bpm_rest', 'bpm_rest'), )

    base_i = ET.fromstring(res.text.encode())
    # parent_id = -1
    process_instance_list = ET.Element('process-instance-list')
    for parent_id in parents:
        for i in base_i.xpath('//parent-instance-id[text()!="-1"]'):
            parent = base_i.xpath('//process-instance-id[text()=%s]/..' % i.text)
            if parent:
                child = parent[0].xpath('/child')
            else:
                continue
            if len(child) == 0:
                child = ET.SubElement(parent[0], 'child')

            child.append(i.getparent())

        if (parent_id == '-1' or parent_id==''):
            var1 = '//process-instance[not(./child)]/process-instance-id'
        else:
            var1 = '//process-instance[./process-instance-id[text()="%s"]]//process-instance[not(./child)]/process-instance-id' % parent_id

        for x in base_i.xpath(var1):
            info = get_info(x.text)
            # additional_info = x.xpath('/active-user-tasks')
            if info.__len__() != 0:
                for inf in info:
                    (x.getparent()).append(inf)

        if (parent_id == '-1' or parent_id==''):
            for i in base_i.xpath('//parent-instance-id[text()="-1"]/..'):
                process_instance_list.append(i)
        elif bool(parent_id):
            parent_element = base_i.xpath('//process-instance-id[text()="%s"]/..' % parent_id)
            if parent_element:
                process_instance_list.append(parent_element[0])
        else:
            print('<h1>Это вообще беда, тут все сломалось<h1>')


        garbage_list = ['process-id', 'process-version', 'initiator', 'process-name', 'correlation-key',
                        'task-container-id', ]
        for g in garbage_list:
            for r in process_instance_list.xpath('//%s' % g):
                parent_r = r.getparent()
                parent_r.remove(r)
                pass

        # tree = ET.ElementTree(process_instance_list)
        # with open('result.xml', 'w') as f:
        #     tree.write('result.xml', pretty_print=True, encoding='UTF-8')
    return ET.tounicode(process_instance_list)
    # print(ET.tounicode(process_instance_list))


if len(sys.argv) > 1:
    print(instance(sys.argv[1].split(',')))
else:
    print(instance())
