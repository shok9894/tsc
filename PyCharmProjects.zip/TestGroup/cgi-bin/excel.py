import requests
import requests.auth
import lxml.etree as ET
from requests import auth
import sys

proxies = {'http': 'http://isizov:shok9894@proxy.tsc.ts:8080/'}


def get_info(instanceId):
    res = requests.get((
            'http://bcvm635.tsc.ts:8080/kie-server/services/rest/server/queries/processes/instances/%s?withVars=True' % instanceId),
        proxies=proxies, auth=auth.HTTPBasicAuth('bpm_rest', 'bpm_rest'))

    info = ET.fromstring(res.text.encode())

    return info.xpath(
        '//active-user-tasks|' +
        '//entry[./key[text()="IN_currentRef"]]|' +
        '//entry[./key[text()="IN_currentStep"]]|' +
        '//entry[./key[text()="IN_clientFullName"]]|' +
        '//entry[./key[text()="IN_taskRefId"]]|' +
        '//entry[./key[text()="IN_applicationHeader"]]'
    )


def clean_process_instance_info(process_instance_list):
    garbage_list = ['process-id', 'process-version', 'initiator', 'process-name', 'correlation-key',
                    'task-container-id', ]
    for g in garbage_list:
        for r in process_instance_list.xpath('//%s' % g):
            parent_r = r.getparent()
            parent_r.remove(r)
    return process_instance_list


def get_instances():
    res = requests.get(
        'http://bcvm635.tsc.ts:8080/kie-server/services/rest/server/queries/processes/instances?pageSize=9999999&page=0',
        proxies=proxies, auth=auth.HTTPBasicAuth('bpm_rest', 'bpm_rest'), )
    return res


def make_xml_tree():
    getted_instances = get_instances()  # Получение всех инстансов
    base_xml = ET.fromstring(getted_instances.text.encode())  # Преобразование текста в xml

    """ Тут цикл для разложения каждого ребенка к по своему предку """
    """____________________________________________________________"""

    for first_child_process in base_xml.xpath(
            '//parent-instance-id[text()!="-1"]'):  # Для каждого не корневого родителя
        his_first_parent = base_xml.xpath(
            '//process-instance-id[text()=%s]/..' % first_child_process.text)  # Номер инстанса предка

        if his_first_parent:  # Почему его может не быть?
            child_list = his_first_parent[0].xpath('/child')  # Получить всех детей
        else:  # Да как так-то?
            continue

        if len(child_list) == 0:  # Есть ли уже дети ?
            child_list = ET.SubElement(his_first_parent[0], 'child')  # Нету, то создаем дите
        child_list.append(first_child_process.getparent())  # Получаем предка не корневого родителя
        # и вкладываем в предка нашего не корневого родителя
    return base_xml  # Возвращаю объект дерево-XML


def make_our_tree(parents=['-1']):
    base_xml = make_xml_tree()
    process_instance_list = ET.Element('process-instance-list')  # Создание элемента root

    for parent_id in parents:  # Если был передан список интерсующих нас инстансов

        if parent_id == '-1' or parent_id == '':
            var1 = '//process-instance[not(./child)]/process-instance-id'  # найти всех детей
        else:
            var1 = '//process-instance[./process-instance-id[text()="%s"]]//process-instance[not(./child)]/process-instance-id' % parent_id  # Найти детей конкретного процесса

        last_child = base_xml.xpath(var1)
        if last_child.__len__() == 0:
            last_child = base_xml.xpath('//process-instance-id[text()="%s"]' % parent_id)

        for process_instance_id in last_child:
            list_info = get_info(process_instance_id.text)
            if list_info.__len__() != 0:
                for info in list_info:
                    (process_instance_id.getparent()).append(info)

        if parent_id == '-1' or parent_id == '':  # Может придти пустая строка
            for parent_instance in base_xml.xpath('//parent-instance-id[text()="-1"]/..'):  # то взять всё
                process_instance_list.append(parent_instance)  # и добавить

        elif bool(parent_id):  # Если есть id
            parent_element = base_xml.xpath('//process-instance-id[text()="%s"]/..' % parent_id)  # то найти по id
            if parent_element:  # нашлось ли что-то
                process_instance_list.append(parent_element[0])  # то добавь это
        else:
            # print('<h1>Это вообще беда, тут все сломалось<h1>')
            pass
        cleaned_process_instance_list = clean_process_instance_info(process_instance_list)
        tree = ET.ElementTree(cleaned_process_instance_list)
        with open('result.xml', 'w') as f:
            tree.write('result.xml', pretty_print=True, encoding='UTF-8')
        return ET.tounicode(cleaned_process_instance_list)


# print(make_our_tree(['72408']))


def refresh_porecess_list():
    base_xml = ET.parse(r'C:\Users\isizov\PycharmProjects\TestGroup\result.xml')
    return base_xml.xpath('//process-instance[./process-instance-id[text()=65929]]')


# print(ET.tounicode(refresh_porecess_list()[0]))
