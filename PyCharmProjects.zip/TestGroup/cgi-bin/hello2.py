import excel

print("Content-type: application/xml")
print('')
# print()
print('<?xml version="1.0" encoding="WINDOWS-1251"?>')
print(excel.instance())

# if len(sys.argv) > 1:
#     print(excel.instance(sys.argv[1].split(',')))
#     pass
# else:
#     print(excel.instance())
#     pass
#
# excel.instance()
