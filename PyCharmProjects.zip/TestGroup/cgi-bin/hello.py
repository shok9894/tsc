import sys

from excel import make_our_tree

print("Content-type: application/xml")
print('')
# print()
print('<?xml version="1.0" encoding="WINDOWS-1251"?>')

if len(sys.argv) > 1:
    print(make_our_tree(sys.argv[1].split(',')))
    pass
else:
    print(make_our_tree())
    pass

# excel.instance()
