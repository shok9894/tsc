import requests
from requests import auth
import json

proxies = {'http': 'http://isizov:shok9894@proxy.tsc.ts:8080/'}
def login():
    res = requests.get(
        'http://bcvm635.tsc.ts/collect-api/login?j_username=puser&j_password=Password123',
        )
    return res.cookies

# print(login())

def get_rest():
    res = requests.get(
        'http://bcvm635.tsc.ts/collect-api/rest/300p30t3/client/3923e339-7470-422c-ad9c-660ffdc96c71',
         cookies=login())
    with open('rest.json', 'w') as f:
        f.write(json.dumps(res.json(), ensure_ascii=False))

    return res.json()

print(get_rest())
# json.dump()
