from selenium.webdriver.support.wait import WebDriverWait
from data import *
from locators import *


class Page(object):
    def __init__(self, driver):
        self.driver = driver

    def fillform6(self):
        def chose(locator, value):
            try:
                self.driver.find_element_by_xpath(locator).click()
                self.driver.find_element_by_xpath(value).click()
            except Exception as err:
                print(err)

        def entr(locator, val):
            x = self.driver.find_element_by_xpath(locator)
            x.clear()
            x.send_keys(val)

        l = SF_6
        d = data.SF6_Data
        elements = self.driver.find_elements_by_xpath
        element = self.driver.find_element_by_xpath

        self.driver.find_element(*CommonLocators.rrr).click()
        self.driver.find_element(*CommonLocators.ChooseForm_06).click()
        try:
            WebDriverWait(self.driver, allData.wait_time).until(lambda x:
                                                                x.find_element(*CommonLocators.Verify_SF_06)
                                                                .is_displayed())
        except:
            print('Scren form don\'t load\n\033[31mTest failure!\033[0m')
            return False

        for subject in elements(l.list_subjects):
            for x in elements(l.obshie_docs):
                x.click()
            element(l.section_1_1).click()
            element(l.section_vivody_i_comments_po_rezultatam).click()
            chose(l.obshaya_pravosposobnost, l.obshaya_pravosposobnost_val)
            chose(l.scpecial_pravosposobnost, l.scpecial_pravosposobnost)
            chose(l.ogranicheniya_vidov_deyatelnosty, l.ogranicheniya_vidov_deyatelnosty_val)
            chose(l.otnoshenie_k_subject_estestv_monopoly, l.otnoshenie_k_subject_estestv_monopoly_val)
            chose(l.otnoshenie_k_subject_deystbiya_zakona, l.otnoshenie_k_subject_deystbiya_zakona_val)
            element(l.section_vivody_i_comments_po_rezultatam).click()

            for section in elements(l.sections_1_2):
                section.click()
                entr(l.grn_number, d.text)
                entr(l.uchastniki_actionery_obshestva, d.text)
                element(l.nalichie_izmeneniy).click()
                section.click()

            # for x in elements(l.sections_1_2):
            #     x.click()

            for x in elements(l.sections_1_3):
                x.click()
                for y in elements(l.dop_docs):
                    y.click()
                x.click()

            element(l.section_vivody_po_rezultatam).click()
            chose(l.vivody_po_rezultatam, l.vivody_po_rezultatam_val)
            element(l.section_vivody_po_rezultatam).click()

            element(l.section_1_4).click()
            chose(l.sdelka, l.sdelka_val)
            for x in elements(l.sdelka_docs):
                x.click()
            chose(l.vivod_po_rezultatam_analyza_krupnoy_sdelki, l.vivod_po_rezultatam_analyza_krupnoy_sdelki_val)
            element(l.section_1_4).click()

            element(l.section_1_5).click()
            chose(l.zainteresovannost_v_sovershenii_sdelki, l.zainteresovannost_v_sovershenii_sdelki_val)
            for x in elements(l.zainteresovannost_doc):
                x.click()
            chose(l.vivod_zainteresovannost_v_sovershenii_sdelki, l.vivod_zainteresovannost_v_sovershenii_sdelki_val)
            element(l.section_1_5).click()

            for section in elements(l.sections_1_6):
                section.click()
                chose(l.polnomochiya_edinolichnogo_icpolnitelnogo_organa,
                      l.polnomochiya_edinolichnogo_icpolnitelnogo_organa_val)
                for x in elements(l.plnomochiya_doc):
                    x.click()
                chose(l.vivod_polnomochiya_edinolichnogo_icpolnitelnogo_organa,
                      l.vivod_polnomochiya_edinolichnogo_icpolnitelnogo_organa_val)
                section.click()

            element(l.section_1_7).click()
            chose(l.itogoviy_vivod, l.itogoviy_vivod_val)
            try:
                element(l.button_next).click()
            except:
                element(l.button_finish).click()



