from data import *
from locators import *
from selenium.webdriver.support.ui import WebDriverWait
import DataBaseConnect
import wsdl
from locators import SF_3


class Page(object):
    def __init__(self, driver):
        self.driver = driver

    def fillform3(self):
        element = self.driver.find_element_by_xpath
        elements = self.driver.find_elements_by_xpath
        list_subjects = self.driver.find_elements_by_xpath(SF_3.list_subjects)
        list_subjects = [x.text for x in list_subjects]
        list_form = [x + 1 for x in range(8)]
        for subject in list_subjects:
            for x in list_form:
                list_yes_on_section = elements(SF_3.list_yes)
                for yes in list_yes_on_section:
                    yes.click()
                try:
                    element(SF_3.button_next).click()
                except Exception as err:
                    print(err)
                    try:
                        element(SF_3.button_finish).click()
                    except Exception as err:
                        print('Ну просто полный FAIL', err)
