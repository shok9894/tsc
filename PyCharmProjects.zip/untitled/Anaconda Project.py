import numpy as np

x = open('nine', 'r')
src = [y.strip('\n').split('.') for y in x]
x.close()
for x in range(len(src)):
    for y in range(len(src[x])):
        src[x][y] = int(src[x][y])
# print(src)
test = [
    [1, 2, 3, 4],
    [4, 5, 6, 7],
    [7, 8, 9, 10],
    [10, 11, 12, 12]
]


# x = 1
# y = 1
# m1 = ((x, y), (x - 1, y), (x + 1, y))
# m2 = ((x, y), (x, y - 1), (x, y + 1))
# m3 = ((x, y), (x-1, y-1), (x+1, y+1))
# m4 = ((x, y), (x-1, y+1), (x+1, y-1))
# ma = ((x, y), m1, m2)
# mb = ((x, y), m3, m4)
# csmooth = ((x, y), ma, mb)
# c = csmooth


def medi(a, x, y):
    if x != 0 and x != len(a)-1:
        if y != 0 and y != len(a[x])-1:
            m1 = np.median([a[x][y], a[x - 1][y], a[x + 1][y]])
            m2 = np.median([a[x][y], a[x][y - 1], a[x][y + 1]])
            m3 = np.median([a[x][y], a[x - 1][y - 1], a[x + 1][y + 1]])
            m4 = np.median([a[x][y], a[x - 1][y + 1], a[x + 1][y - 1]])
            ma = np.median([a[x][y], m1, m2])
            mb = np.median([a[x][y], m3, m4])
            Csmooth = np.median([a[x][y], ma, mb])
            C = int(Csmooth)
            return C
        else:
            return a[x][y]
    else:
        return a[x][y]

def sr(a, x, y):
    if x != 0 and x != len(a)-1:
        if y != 0 and y != len(a[x])-1:

            m1 = (a[x][y]+ a[x - 1][y]+ a[x + 1][y])/3
            m2 = (a[x][y]+ a[x][y - 1]+ a[x][y + 1])/3
            m3 = (a[x][y]+ a[x - 1][y - 1]+ a[x + 1][y + 1])/3
            m4 = (a[x][y]+ a[x - 1][y + 1]+ a[x + 1][y - 1])/3
            ma = (a[x][y]+ m1+ m2)/3
            mb = (a[x][y]+ m3+ m4)/3
            Csmooth = (a[x][y]+ ma+ mb)/3
            C = int(Csmooth)
            return C
        else:
            return a[x][y]
    else:
        return a[x][y]



def im_sr(array):
    for x in range(len(array)):
        for y in range(len(array[x])):
            # print('[', x, ';', y, ']=', sep='', end='')
            # r = int(src[x][y])
            # print(src[x][y], end='-')
            array[x][y] = sr(array, x, y)
            # print(r - int(src[x][y]))

im_sr(src)