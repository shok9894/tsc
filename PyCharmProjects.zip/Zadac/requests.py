import requests
from lxml import html

proxies = {
    "https": "https://ishakirov:shok9894@proxy.tsc.ts:8080/"
}

x = requests.get("https://www.sc.edu/about/directory/?name=Zhao", proxies=proxies)

ht = html.fromstring(x.text)

element = ht.xpath('//table[@id="directorystaff"]/tbody/tr/td')
for el in element:
    print(el.text)