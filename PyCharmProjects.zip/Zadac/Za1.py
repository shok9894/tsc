file_in = open('input.xml', 'r', encoding='UTF-8')
file_setting = open('setting.txt', 'r', encoding='UTF-8')
file_out = open('output.csv', 'w')


def forma(file):
    li = ['date', 'vchar', 'numb', '', 'datetime']
    y = []
    for x in file:
        while ';;' in x:
            x = x.replace(';;', ';').strip('\n')
        x = x.lstrip(';').split(';')[1:] if x.lstrip(';').split(';')[0] in li else x.split(';')
        x.remove('') if '' in x else x
        y.append(x)
    with open('setting_out.txt', 'w'):
        pass
    out = open('setting_out.txt', 'a', encoding='UTF-8')

    for x in y:
        out.write(x[0] + ';' + x[1] + '\n')
    out.close()
    # return y


forma(file_setting)
file_setting.close()


# x = file_in.read()
def replyka(file):
    y = ''

    for x in file:
        try:
            y = y + x.encode('cp1251').decode('utf8')
            # print(x.encode('cp1251').decode('utf8'))
        except Exception as err:
            y = y + x
            # print(err)
            pass
    x = y
    out = open('setting_out.txt', encoding='UTF-8')
    for st in out:
        st1 = st.strip('\n').split(';')
        x = x.replace(('</' + st1[0] + '>'), '')
        x = x.replace(('<' + st1[0] + '>'), st1[0]+';'+st1[1] + ';')
        x = x.replace(('<' + st1[0] + '/>'), st1[0]+';'+st1[1] + ';')
    out.close()
    with open('output_tmp.csv', 'w'):
        pass

    out = open('output_tmp.csv', 'w', encoding='cp1251')
    out.write(x)
    # for s in x:
    #     out.write(s)
    return True



out = replyka(file_in)
