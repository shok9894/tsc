sl = open('slovar.txt')
fil = open('setting.txt', encoding='UTF-8')
# setting = fil.read()

li = ['date', 'vchar', 'numb', '', 'datetime']
y = []
for x in fil:

    while ';;' in x:
        x = x.replace(';;', ';').strip('\n')
    x = x.lstrip(';').split(';')[1:] if x.lstrip(';').split(';')[0] in li else x.split(';')
    x.remove('') if '' in x else x
    y.append(x)

slovar = sl.read()
i = 0
for x in y:
    if x[0] not in slovar:
        i += 1
        print(x[0:2])
    else:
        True
print(i)

