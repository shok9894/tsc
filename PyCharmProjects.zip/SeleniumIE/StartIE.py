from selenium import webdriver
from selenium.webdriver.common.desired_capabilities import DesiredCapabilities

capabilities = DesiredCapabilities.INTERNETEXPLORER.copy()
capabilities["platform"] = "WIN7"
capabilities["browserName"] = "internet explorer"
capabilities["ignoreProtectedModeSettings"] = True
capabilities["IntroduceInstabilityByIgnoringProtectedModeSettings"] = True
capabilities["nativeEvents"] = True
capabilities["ignoreZoomSetting"] = True
capabilities["requireWindowFocus"] = True
capabilities["INTRODUCE_FLAKINESS_BY_IGNORING_SECURITY_DOMAINS"] = True
capabilities["proxy"] = {"proxyType": "manual", "httpProxy": "ishakirov:shok9894@proxy.tsc.ts:8080"}



browser = webdriver.Ie.iedriver (capabilities=capabilities)
browser.get("http://bcvm187:8180/ui/#/")
# browser.quit()


