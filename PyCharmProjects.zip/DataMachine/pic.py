import pandas as pd
import matplotlib.pyplot as plt, matplotlib.image as mpimg
from sklearn.model_selection import train_test_split
from sklearn import svm
import time,sys
#%matplotlib inline
k = time.time()
print('Ну старт что-ли')
# Считывание файла в dataframe
labeled_images = pd.read_csv(r'D:\DataMachine\train.csv')

# Разделение картинок и значений
l = 5000
images = labeled_images.iloc[0:l, 1:]
print('images')
labels = labeled_images.iloc[0:l, :1]
print('labels')
# Вот и что это see: train_test_split()
# FutureWarning: From version 0.21, test_size will always complement train_size unless both are specified.
#
train_images, test_images, train_labels, test_labels = train_test_split(images, labels, test_size=0.01, random_state=0)
# Это та же строка но с решенной проблемой
# train_images, test_images,train_labels, test_labels = train_test_split(images, labels, random_state=0)
i = 1
# Представление i-той картинки в виде матрицы
#img = train_images.iloc[i].as_matrix()
# преобразование матрицы из 1*784 в 28*28
#img = img.reshape((28, 28))

# Это вывод картинки ?
# надо бы почитать
#print(plt.imshow(img, cmap='gray'))
#print(plt.title(train_labels.iloc[i, 0]))
# __________________________________
# Вот тут картинка уже отображается
# __________________________________
# Вот она Out[5]: <matplotlib.text.Text at 0xcd0e2e8>

# Вывод гистограммы распеределения
#input('Press Enter')
#print(plt.hist(train_images.iloc[i]))
# Out[6]:
#(array([ 674.,    5.,   12.,    3.,    5.,   14.,    8.,    2.,   13.,   48.]),
# array([   0. ,   25.5,   51. ,   76.5,  102. ,  127.5,  153. ,  178.5, 204. ,  229.5,  255. ]), <a list of 10 Patch objects>)


# Тут магия
#clf = svm.SVC()
# После следующий команды верется какой то объект,
# а вообще это нужно что бы привести какую то SVM модель к полученным тестовым данным
#clf.fit(train_images, train_labels.values.ravel())
# Возваращет среднуюю точность
# Тестовые данные, ответы к тестам
# получается происходит сопостовление расчетных ответов с известными ответами
#print(clf.score(test_images, test_labels))
# отображается средняя точность угадывания
# Out[7]: 0.1024

# Похоже на IF если оттенок серого больше 1 то пиксель черный
test_images[test_images > 0] = 1
train_images[train_images > 0] = 1
print('moduling')
print(round((time.time()-k)//60), round((time.time()-k)-((time.time()-k)//60)*60), 'sec', sep='.')
# Создание матрицы с размерностью 28*28
#img = train_images.iloc[i].as_matrix().reshape((28, 28))

# Еще один вывод картинки
# Картинка теперь двух цветов
# cmap - похоже (color map) кодировка цветов бинарная
#
#plt.imshow(img, cmap='binary')
# Это подпись к картинке
#plt.title(train_labels.iloc[i])
# Тут уже отображена картинка
# ----------------------
#input('Press Enter')
# Вывод гистаграммы цветового распределения
#print(plt.hist(train_images.iloc[i]))
# -----------------------------------

# С 0 обучаем нашу систму, c использованием от-бинариных картинок
clf = svm.SVC()
clf.fit(train_images, train_labels.values.ravel())

print('Прогнозы уже обученой системы корректны на', clf.score(test_images, test_labels)*100, '%')
# Результирующий вывод
# Out[10]: 0.88880000000000003


# Запуск нашего монстра на тестовые картинки
#test_data = pd.read_csv(r'D:\DataMachine\test.csv')
#test_data[test_data > 50] = 1
# На первые 5000 тысяч картинок
results = clf.predict(test_images[0:l])
# Вывод результатов
print(results)
# Out[12]: array([2, 0, 9, ..., 1, 7, 3], dtype=int64)
# -------------------------------------------
# Выгрузка результатов в новый DATA FRAME
df = pd.DataFrame(results)
# Название клетки
df.index.name = 'ImageId'
# Следующая клетка
df.index += 1
# Название колонки
df.columns = ['Label']
# Экспорт в CSV файл
print('-'*80)
print(round((time.time()-k)//60), 'min', round((time.time()-k)-((time.time()-k)//60)*60), 'sec')

f = open('time.txt', 'a')
d =''
str_res = str(results).replace('\n', '').strip('[]').replace(' ', '')
str_lab = str(test_labels.label).replace(chr(32), '-').replace('\n', ';')
for r in range(len(results)):
    f.write('%d;%s\n' % (r, str_res[r]))

f.close()
df.to_csv(r'results.csv', header=True)


