import django
print(django.__version__)