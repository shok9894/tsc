from django.shortcuts import render


# Create your views here.
def index(request):
    return render(request, 'web/homepage.html', {'process_instance_id': ['325', '326', '327']})


def instance(request):
    return render(request, 'web/instance.html')

