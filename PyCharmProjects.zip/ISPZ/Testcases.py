import sys
import unittest
import time
import logging
import json

from selenium.webdriver.common.keys import Keys
from selenium.webdriver.remote.remote_connection import LOGGER
from selenium import webdriver
import page
from data import *
from locators import *
from page import MainFunction, ExtFunction

logger = logging.getLogger('ISPZ_logs')
logger.setLevel(logging.DEBUG)
formatter = logging.Formatter('%(asctime)s - %(levelname)s - %(message)s')
fh = logging.FileHandler('log_file.txt')
fh.setLevel(logging.DEBUG)
fh.setFormatter(formatter)
logger.addHandler(fh)

ch = logging.StreamHandler()
ch.setLevel(logging.DEBUG)
ch.setFormatter(formatter)
logger.addHandler(ch)
# logger.debug('This is a test log message.')
log = logger.debug


class Atest(unittest.TestCase):
    gsz_name = ''

    def setUp(self):
        # logging.basicConfig(filename="sample.log", level=logging.INFO)
        self.driver = webdriver.Chrome(r'C:\Users\isizov\PycharmProjects\ISPZ\chromedriver.exe')
        self.driver.maximize_window()
        self.driver.implicitly_wait(Data.wait_time)
        self.driver.set_page_load_timeout(Data.wait_time)
        self.driver.get(LoginLocators.site)

    def test1(self):  # Test log-in
        MainFunction.wait_page_load(self, LoginLocators.go_button)
        MainFunction.login(self, LoginLocators.user, LoginLocators.password)
        MainFunction.wait_page_load(self, PortalLocator.portal)

    def test2(self):  # Test load debtors
        self.driver.get(LoginLocators.site + "loadDebtor")
        # MainFunction.clickAndWait(self, , LoadDeptorsLocators.document)
        assert page.ExtFunction.gen_excel(self)
        MainFunction.wait_page_load(self, LoadDeptorsLocators.document)
        MainFunction.entrFile(self, LoadDeptorsLocators.document, Data.DeptorsFile)
        MainFunction.entr(self, LoadDeptorsLocators.nomer_spiska, Data.nomer_spiska)
        MainFunction.entr(self, LoadDeptorsLocators.dataKRPZ, Data.now)
        MainFunction.entr(self, LoadDeptorsLocators.gsz, Data.gsz_name)
        gsz_name = Data.gsz_name
        self.gsz_name = gsz_name
        print('Использоую ГСЗ: %s' % gsz_name)
        log('Использоую ГСЗ: %s' % gsz_name)
        MainFunction.click(self, LoadDeptorsLocators.testFile)
        MainFunction.click(self, LoadDeptorsLocators.download)

        if not (MainFunction.wait_page_load(self, LoadDeptorsLocators.deptors_with_err)):

            try:
                print("\nПолучена ошибка:",
                      str(self.driver.find_element_by_xpath(LoadDeptorsLocators.download_err).text).split('\n')[
                          2])
            except:
                print('Ошибка не отобразилась, см. скриншот')
            finally:
                last_element = self.driver.switch_to.active_element
                print('x-' * 25, 'The last active element (size, tag_name, text):', last_element.size,
                      last_element.tag_name,
                      last_element.text, sep='\n')
                # self.fail()
                tearDown(self, 'Donload error')


        elif self.driver.find_element_by_xpath(LoadDeptorsLocators.deptors_with_err).text == '0':
            MainFunction.click(self, LoadDeptorsLocators.complete)
            print("\nSuccessful download deptors")
        else:
            err_strings = self.driver.find_elements_by_xpath(LoadDeptorsLocators.err_strings)
            print("Обнаружены ошибки при загрузке должников:")
            for last_element in range(1, len(err_strings), 2):
                print(err_strings[last_element - 1].text, err_strings[last_element].text, sep=' - ')
                tearDown(self, 'Donload error')

    def test3(self, dontFinishedTask=None):
        if dontFinishedTask:
            spisok = dontFinishedTask
        else:
            debtors_list = ExtFunction.debtors_list(self)
            spisok = list(map(lambda x: x.attrib['text'], debtors_list))

        for deptor in spisok:
            print('-' * 25, 'Start work for: %s' % deptor, sep='\n')
            if MainFunction.find(self, PortalLocator.refreshDeptor % deptor):
                if not MainFunction.clickAndWait(self, PortalLocator.refreshDeptor % deptor,
                                                 PortalLocator.complete):
                    tearDown(self)
                time.sleep(1)
                if not MainFunction.clickAndWait(self, PortalLocator.complete,
                                                 PortalLocator.portal):
                    tearDown(self)
            if not MainFunction.clickAndWait(self, PortalLocator.fillDeptor % deptor,
                                             PortalLocator.complete):
                tearDown(self)
            if not MainFunction.find(self, FillDeptor.uadress):
            # if deptor.attrib['type'] == '3':
                if not ExtFunction.fill_FL(self, deptor): tearDown(self)
            else:
                if not ExtFunction.fill_KD(self, deptor): tearDown(self)
                if self.gsz_name =='':
                    # self.gsz_name = (MainFunction.find(self, FillDeptor.gsz_name)).text
                    self.gsz_name = input()
                    print(self.gsz_name)
                    log(self.gsz_name)

            if not MainFunction.clickAndWait(self, PortalLocator.complete,
                                             PortalLocator.fillDeptor % deptor):
                tearDown(self)
            print('Debtor filled')
        print("\nAll debtors are filled")

    def test4(self):

        if not MainFunction.find(self, PortalLocator.portal):
            self.test1()
        log('start test 4')
        self.driver.get_network_conditions()
        deptors = ExtFunction.debtors_list(self)
        # x = MainFunction.find(self, PortalLocator.fillDeptor % deptors[0].attrib['text'])
        # x = MainFunction.find(self, PortalLocator.refreshDeptor % deptors[0].attrib['text'])
        dontFinishedTask = list(set(list(map(lambda x: x.attrib['text'], deptors))) & set(
            list(map(lambda x: x.text, self.driver.find_elements_by_xpath(PortalLocator.allDeb)))))

        if dontFinishedTask.__len__() != 0:  # Есть
            log('Найдены не завершенные задачи')

            # x.click()  # незаве  ршенные задачи
            # MainFunction.wait_page_load(self, PortalLocator.complete)
            # self.gsz_name = self.driver.find_element_by_xpath(FillDeptor.gsz_name).text
            # print(self.gsz_name)
            # if MainFunction.find(self, FillDeptor.obespechenie):  # Заполненны договора
            #     # if 1 == 2:
            #     log('Задача была заполненна, но не завершена')
            #     if not MainFunction.clickAndWait(self, PortalLocator.complete, PortalLocator.portal): tearDown(self)
            #     log("Завершаем все задачи")
            #     for deptor in deptors[1:]:
            #         if not MainFunction.clickAndWait(self, PortalLocator.fillDeptor % deptor.attrib['text'],
            #                                          PortalLocator.complete): tearDown(self)
            #
            #         if not MainFunction.clickAndWait(self, PortalLocator.complete, PortalLocator.portal): tearDown(self)
            # else:
            #     log('Задача не была выполненна')
            #     MainFunction.clickAndWait(self, PortalLocator.hold_over, PortalLocator.portal)
            self.test3(dontFinishedTask=dontFinishedTask)  # Не заполненны, запускаем заполнение
            # self.test4()
        else:
            log("Старых задач не найдено")
        if self.gsz_name == '':
            self.test2()  # Не было задач
            # self.assertIsNotNone(self.test2())
            self.test3()  # Запустить заполнение
            # self.test4()

        if self.gsz_name != '':
            MainFunction.wait_page_load(self, PortalLocator.portal)
            self.driver.get(LoginLocators.site + "loadDebtor")

            MainFunction.wait_page_load(self, LoadDeptorsLocators.document)
            MainFunction.entrFile(self, LoadDeptorsLocators.document, Data.DeptorsFile)
            MainFunction.entr(self, LoadDeptorsLocators.nomer_spiska, Data.nomer_spiska)
            MainFunction.entr(self, LoadDeptorsLocators.dataKRPZ, Data.now)
            MainFunction.entr(self, LoadDeptorsLocators.gsz, self.gsz_name)
            (self.driver.switch_to.active_element).send_keys(Keys.ARROW_DOWN)
            (self.driver.switch_to.active_element).send_keys(Keys.ENTER)
            MainFunction.click(self, LoadDeptorsLocators.nomer_spiska)
            # MainFunction.TAB(self)

            time.sleep(1)
            MainFunction.click(self, LoadDeptorsLocators.download)

            if not (MainFunction.wait_page_load(self, LoadDeptorsLocators.deptors_with_err)):

                try:
                    print("\nПолучена ошибка:",
                          str(self.driver.find_element_by_xpath(LoadDeptorsLocators.download_err).text).split('\n')[
                              2])
                except:
                    print('Ошибка не отобразилась, см. скриншот')
                finally:
                    last_element = self.driver.switch_to.active_element
                    print('x-' * 25, 'The last active element (size, tag_name, text):', last_element.size,
                          last_element.tag_name,
                          last_element.text, sep='\n')
                    # self.fail()
                    tearDown(self, 'Donload error')

            # Надо нажать на завершить
            MainFunction.clickAndWait(self, LoadDeptorsLocators.complete, PortalLocator.portal)
            # Проверить чтfо есть задача на чек-лист
            if MainFunction.find(self, PortalLocator.check_list % self.gsz_name):
                print('Уррааа!... Все получилось')
                log('Уррааа!... Все получилось')
            else:
                print('WTF???')
                log('WTF???')
        print('Стоп')


def tearDown(self, err=None):
    screenshot = r'D:\debtor\Screen %s.png' % time.strftime("%d.%m.%y %H-%M-%S")
    if self.driver.get_screenshot_as_file(screenshot):
        print(screenshot)
        log(screenshot)

    else:
        print('Without screen...')
        log('Without screen...')
    self.driver.close()

    if err != None:
        raise Exception(err)
    else:
        sys.exit()



if __name__ == "__main__":
    unittest.main()
