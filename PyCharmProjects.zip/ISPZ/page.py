import os
from lxml import etree
from selenium.webdriver.common.keys import Keys
from data import Data
from selenium.webdriver.support import expected_conditions
from locators import *
from selenium.webdriver.support.ui import WebDriverWait
import random
from openpyxl import load_workbook





class BasePage(object):
    """Base class to initialize the base page that will be called from all pages"""

    def __init__(self, driver):
        self.driver = driver



class MainFunction(BasePage):

    def find(self, locator):
        try:
            element = self.driver.find_element_by_xpath(locator)
            return element
        except:
            return False

    def TAB(self, locator=''):
        try:
            if locator != '':
                self.driver.find_element_by_xpath(locator).send_keys(Keys.TAB)
            else:
                (self.driver.switch_to.active_element).send_keys(Keys.TAB)
            return True
        except Exception as err:
            print('Не смог нажать Тав по %s и возникла ошибка:\n%s' % (
                ('текущему элементу' if locator == '' else locator), err))
            return False

    def login(self, user, password):
        try:
            user = self.driver.find_element_by_xpath(user)
            password = self.driver.find_element_by_xpath(password)
            user.clear()
            password.clear()
            user.send_keys(Data.user)
            password.send_keys(Data.password)
            # self.driver.find_element_by_xpath(LoginPageLocators.go_button).click()
            password.submit()
            MainFunction.wait_page_load(self, PortalLocator.portal)
            return True
        except Exception as err:
            print("\nНе смог залогиниться пользователем '%s' " % user, err, sep='\n\n', end='\n')
            return False

    def wait_page_load(self, page):
        try:
            WebDriverWait(self.driver, Data.wait_time).until(expected_conditions.presence_of_element_located(
                (By.XPATH, page)))  # lambda x: x.find_element_by_xpath(page).is_displayed())
            return True
        except:
            # return False
            return True

    def clickAndWait(self, kuda, chto):
        try:
            if MainFunction.click(self, kuda):
                if MainFunction.wait_page_load(self, chto):
                    return True
                else:
                    return False
            else:
                return False
        except Exception as err:
            print('Не дождался %s и получил:\n%s' % (chto, err))
            return False

    def choose(self, locator, value):
        try:
            self.driver.find_element_by_xpath(locator).click()
            self.driver.find_element_by_xpath(value).click()
            return True
        except Exception as err:
            print("\nНе смог выбрать значение '%s' для элемента '%s'" % (value, locator), err, sep='\n\n', end='\n')
            return False

    def click(self, locator):
        try:
            x = self.driver.find_element_by_xpath(locator)
            x.location_once_scrolled_into_view
            x.click()
            return True
        except:
            try:
                self.driver.execute_script("arguments[0].click()", x)
                return True
            except Exception as err:
                z = self.driver.switch_to.active_element
                print("\nНе смог выполнить клик по элементу '%s'" % locator, err, sep='\n\n', end='\n')
                print('The last active element(size, tag_name, text):', z.size, z.tag_name, z.text, sep='\n\n')

                return False

    def entr(self, locator, value):
        if type(locator) == type(str()):
            try:
                x = self.driver.find_element_by_xpath(locator)
                x.location_once_scrolled_into_view
                x.clear()
                x.send_keys(value)
                return True
            except Exception as err:
                print("\nНе смог записать значение '%s' для элемента '%s'" % (value, locator), err, sep='\n\n',
                      end='\n')

                return False
        else:
            try:
                locator.clear()
                locator.send_keys(value)
                return True
            except Exception as err:
                print("\nНе смог записать значение '%s' для элемента '%s'" % (value, locator), err, sep='\n\n',
                      end='\n')
                return False

    def entrFile(self, locator, value):
        try:
            self.driver.find_element_by_xpath(locator).location_once_scrolled_into_view
            x = self.driver.find_element_by_xpath(locator)
            # x.clear()
            x.send_keys(os.path.abspath(value))
            return True
        except Exception as err:
            print("\nНе смог загрузить файл '%s' для элемента '%s'" % (value, locator), err, sep='\n\n', end='\n')
            return False


class ExtFunction(BasePage):
    """Search results page action methods come here"""
    xmlFile = "debtorsData.xml"
    with open(xmlFile, encoding='UTF-8') as fobj:
        xml = fobj.read()
    et = etree.fromstring(xml)

    def gen_excel(self):
        try:
            wb = load_workbook(Data.DeptorsFile)
            ws = wb[wb.sheetnames[0]]

            wc = (ws['B:B'])[1:]
            wc2 = (ws['A:A'])[2:]
            debtors = ExtFunction.debtors_list(self)
            debtors_list = list(map(lambda x: x.attrib['text'], debtors))
            for x in wc:
                inn = str(random.randint(1000000, 9999999))
                if len(str(x.value)) == 12:
                    x.value = inn + '11111'
                else:
                    x.value = inn + '111'

            for (y, d) in zip(wc2, debtors_list):
                y.value = str(d)
            wb.save(filename=Data.DeptorsFile)
            wb.close()
            return True
        except Exception as err:
            print("\nОшибка при работе с файлом", err, sep='\n\n')
            return False

    def debtors_list(self):
        # def debtors_list():
        element = ExtFunction.et.xpath('//debtor')
        return element

    def fill_KD(self, deptor):

        MainFunction.click(self, FillDeptor.resident)
        debData = ExtFunction.et.xpath
        # element = ExtFunction.et.xpath('//debtor[@text="%s"]/obsv/*')
        element = debData('//debtor[@text="%s"]/obsv/*' % deptor)
        ob_sv = {x.tag: x.text for x in element}
        MainFunction.entr(self, FillDeptor.rfilial, ob_sv['rf'])
        # MainFunction.TAB(self, FillDeptor.rfilial)
        self.driver.find_element_by_xpath(FillDeptor.rfilial).send_keys(Keys.TAB)
        MainFunction.entr(self, FillDeptor.vid_deyat, ob_sv['vid_deyat'])
        self.driver.find_element_by_xpath(FillDeptor.vid_deyat).send_keys(Keys.TAB)
        MainFunction.entr(self, FillDeptor.uadress, ob_sv['Uaddr'])
        MainFunction.entr(self, FillDeptor.fadress, ob_sv['Faddr'])
        # --------------------------------------------------
        MainFunction.click(self, FillDeptor.obyazatelstva)
        # --------------------------------------------------
        kol_kds = int(debData('count(//debtor[@text="%s"]/kds/kd)' % deptor))
        try:
            for kds in range(kol_kds):
                kd_list = [x.text for x in debData('//debtor[@text="%s"]/kds/kd[%s]/*' % (deptor, kds + 1))]
                print('|- for KD №%s' % kd_list[1])
                MainFunction.click(self, FillDeptor.obyazatelstva)
                MainFunction.entr(self, FillDeptor.rfilial, kd_list[0])
                self.driver.find_element_by_xpath(FillDeptor.rfilial).send_keys(Keys.TAB)
                (self.driver.switch_to.active_element).click()
                MainFunction.entr(self, FillDeptor.numberS_CD % str(kds + 1), kd_list[1])
                try:
                    for x, z in zip(
                            self.driver.find_elements_by_xpath(FillDeptor.dataS_CD % (str(1), str(kds + 1))),
                            kd_list[2:]):
                        x.clear()
                        x.send_keys(str(z))
                except Exception as err:
                    print("\nНе смог ввести '%s' для элемента где placeholder='%s'" % (
                        z.value, x.get_attribute('placeholder')), err, sep='\n\n', end='\n')
                print('filled.........')
        except Exception as err:
            print('Failed fill credit obyaz\n%s' % err)
            return False

        if kol_kds != 0:
            ExtFunction.fill_DO(self, deptor)
            print('Obespech dogovor filled.........')
            ExtFunction.fill_PZ(self, deptor)
            print('Predmet zaloga filled.........')
        return True

    def fill_DO(self, deptor):
        debData = ExtFunction.et.xpath
        MainFunction.click(self, FillDeptor.obespechenie)

        kds = debData('//debtor[@text="%s"]/kds/kd' % deptor)
        for kd in range(len(kds)):
            dos = debData('//debtor[@text="%s"]/kds/kd[%s]/dos/do' % (deptor, str(kd + 1)))
            for do in range(len(dos)):
                MainFunction.click(self, FillDeptor.add_btn % str(kd + 1))
                do_data = [x.text for x in
                           debData('//debtor[@text="%s"]/kds/kd[%s]/dos/do[%s]/*/preceding-sibling::*' % (
                               deptor, str(kd + 1), str(do + 1)))]
                print('|- for DO №%s' % do_data[1])
                MainFunction.entr(self, FillDeptor.zalogodats % (str(kd + 1), str(do + 1)), do_data[0])
                MainFunction.TAB(self, FillDeptor.zalogodats % (str(kd + 1), str(do + 1)))
                (self.driver.switch_to.active_element).click()

                for x, z in zip(self.driver.find_elements_by_xpath(FillDeptor.dataS_CD % (str(kd + 1), str(do + 1))),
                                do_data[1:]):
                    try:
                        x.clear()
                        if z == 'any':
                            x.send_keys(Keys.TAB)
                        else:
                            x.send_keys(str(z))
                            x.send_keys(Keys.TAB)
                    except:
                        MainFunction.TAB(self)
                print('filled.........')

    def fill_PZ(self, deptor):
        switch = (self.driver.switch_to)
        debData = ExtFunction.et.xpath
        kds = debData('//debtor[@text="%s"]/kds/kd' % deptor)
        for kd in range(len(kds)):
            dos = debData('//debtor[@text="%s"]/kds/kd[%s]/dos/do' % (deptor, str(kd + 1)))
            for do in range(len(dos)):
                MainFunction.click(self, FillDeptor.pz_podrob % (str(kd + 1), str(do + 1)))
                pzs = debData('//debtor[@text="%s"]/kds/kd[%s]/dos/do[%s]/pzs/pz' % (deptor, str(kd + 1), str(do + 1)))
                MainFunction.entr(self, FillDeptor.pz_predmet_ob, Data.zalog)
                MainFunction.TAB(self)
                for pz in range(len(pzs)):
                    MainFunction.click(self, FillDeptor.pz_add_btn)
                    pz_data = debData(
                        '//debtor[@text="%s"]/kds/kd[%s]/dos/do[%s]/pzs/pz[%s]/*' % (
                            deptor, str(kd + 1), str(do + 1), str(pz + 1)))
                    print('|- for PZ №%s' % pz_data[1].text)
                    MainFunction.click(self, FillDeptor.pz_t1 % (str(pz + 1), '2'))
                    MainFunction.TAB(self)
                    MainFunction.entr(self, FillDeptor.pz_t1 % (str(pz + 1), '3') + '//input', pz_data[1].text)
                    MainFunction.TAB(self)
                    x = self.driver.find_element_by_xpath(FillDeptor.pz_t2 % str(pz + 1))
                    x.click()
                    for z in range(len(pz_data[2:])):
                        x = self.driver.switch_to.active_element
                        if x.get_attribute('type')!='checkbox':
                            x.clear()
                        else:
                            x.send_keys(Keys.TAB)

                        if pz_data[2:][z].tag == 'posledZalog':
                            pass
                            # continue
                        elif pz_data[2:][z].text == 'any':
                            x.send_keys(Keys.TAB)
                        else:
                            x.send_keys(str(pz_data[2:][z].text))
                            x.send_keys(Keys.TAB)
                    print('filled.........')
                (switch.active_element).send_keys(Keys.ESCAPE)
        return True

    def fill_FL(self, deptor):
        now = (self.driver.switch_to)
        # MainFunction.click(self, FillDeptor.resident)
        debData = ExtFunction.et.xpath
        element = debData('//debtor[@text="%s"]/obsv/*' % deptor)
        ob_sv = {x.tag: x.text for x in element}
        MainFunction.entr(self, FillDeptor.rfilial, ob_sv['rf'])
        MainFunction.TAB(self)
        MainFunction.TAB(self)
        MainFunction.TAB(self)
        MainFunction.entr(self, now.active_element, ob_sv['Uaddr'])
        MainFunction.TAB(self)
        MainFunction.entr(self, now.active_element, ob_sv['Faddr'])
        # MainFunction.clickAndWait(self, PortalLocator.hold_over, PortalLocator.fillDeptor % deptor)
        return True
        # print('|- filled.........')
        # self.driver.find_element_by_xpath(FillDeptor.rfilial).send_keys(Keys.TAB)
        # MainFunction.entr(self, FillDeptor.vid_deyat, ob_sv['vid_deyat'])
        # self.driver.find_element_by_xpath(FillDeptor.vid_deyat).send_keys(Keys.TAB)

    def hasInstance(self):
        pass

