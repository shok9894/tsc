from selenium.webdriver.common.by import By


class LoginLocators(object):
    site = "http://bcvm635.tsc.ts/ui/#/"
    go_button = '//button[text()="Войти"]'
    user = '//input[@placeholder="Логин"]'
    password = '//input[@placeholder="Пароль"]'


class LoadDeptorsLocators(object):
    document = "//input[@type='file']"
    nomer_spiska = "//div[text()='Номер списка']/..//input"
    gsz = "//div[text()='Название ГСЗ']/..//input"
    dataKRPZ = '//*[text()="Дата КРПЗ"]/following::input'
    testFile = "//div[text()='Тестовый файл']/..//div[@class='react-toggle-track']"
    download = "//button[text()='Загрузить']"
    complete = "//button[text()='Завершить']"
    data_err = "//*[text()='Причина некорректной загрузки']"
    err_strings = "//h4[contains(text(),'Результат')]/..//td[./preceding::th[contains(text(),'Причина')]][1]|" \
                  "//h4[contains(text(),'Результат')]/..//td[./preceding::th[contains(text(),'Причина')]][last()]"
    deptors_with_err = \
        "//div[text()='Результат анализа файла']/..//td[./preceding::th[contains(text(),'ошибкой')]][last()]"
    download_err = "//div[@class='fade in modal']//div[@class='modal-header']"


class PortalLocator(object):
    portal = "//button[text()='Выйти']"
    fillDeptor = "//td[contains(text(),'%s')]/preceding-sibling::td[contains(text(),'Заполнение')]"
    refreshDeptor = "//td[contains(text(),'%s')]/preceding-sibling::td[contains(text(),'Обновление')]"
    allDeb = "//td[position() =1+count(//th[.//*[contains(text(),'Должник')]]/preceding::th)]"
    check_list = "//td[text()='Заполнить чек-лист первичных мероприятий']/following::td[contains(text(),'%s')]/.."
    complete = "//button[text()='Завершить задачу']"
    hold_over = "//button[text()='Отложить задачу']"
    name_task = "(//preceding-sibling::td[./following::td[contains(text(),'%s')]])[2]"

class FillDeptor(object):
    gsz_name = "//*[text()='ГСЗ:']/following-sibling::*"
    resident = "//div[./preceding-sibling::div[text()='Резидент']]//div[@class='react-toggle']"
    rfilial = '//div[./preceding-sibling::div[contains(text(),"РФ")]]//div[@class="Select-input"]//input'
    vid_deyat = "//div[./preceding-sibling::div[text()='Вид деятельности']]//div[@class='Select-input']//input"
    uadress = "//div[./preceding-sibling::div[text()='Юридический адрес']]//input"
    fadress = "//div[./preceding-sibling::div[text()='Фактический адрес']]//input"
    obyazatelstva = "//a[text()='Структура обязательств']"
    obespechenie = "//a[text()='Обеспечение']"
    ob_sv = "//a[text()='Общие сведения']"
    name_rf = "//div[./preceding-sibling::div[text()='Выберите наименование РФ']]//div[@class='Select-input']"
    numberS_CD = "((//table)[1]//input)[%s]"
    dataS_CD = "((//table)[position() mod 2=0])[%s]/tbody/tr[%s]/td//input[1]"
    add_btn = "(//button[text()='Добавить'])[%s]"
    zalogodats = '(((//table)[position() mod 2=1])[%s]/tbody/tr/td[2])[%s]//input'
    # ________________________________________________
    pz_podrob = '(((//table)[position() mod 2=0])[%s]/tbody/tr[%s]/td/button)[1]'
    pz_predmet_ob = "//*[text()='Предмет обеспечения']//following::input"
    pz_add_btn = "//h4[contains(text(),'Список')]/../..//button[text()='Добавить']"
    pz_t1 = "(//h4[contains(text(),'Список')]/../..//tbody)[1]/tr[%s]/td[%s]"
    pz_t2 = "(//h4[contains(text(),'Список')]/../..//tbody)[2]/tr[%s]/td//input"


class SF_1(object):
    Go_Button = "//button[descendant::*[contains(text(),'Вперед')]]"
    Go_Button_in_Master = '//div[@style="padding-bottom: 8px;"]//*[contains(text(),\'Вперед\')]'
    button_next = "//span[text()='Вперед']"
    button_finish = "//span[text()='Завершить задачу']"
    Buba = (By.XPATH,
            "//input[(./ancestor::*/*[contains(text(),'Отметка ВР о предоставлении документа')]) "
            "and ./..//*[contains(text(),'Да')]]")
    actual_name_form = '//div[@style="float: right; width: 85%;"]//div[@class="accordion_grey"]'
    obj_list_sections = '//div[@style="margin-left: 37px;"]//ancestor::div[contains(@class,"accordion_")]'
    list_subjects = '//div[@style="padding: 8px 0px; float: left; width: 15%;"]/div'
    list_doc_on_sf = "//div[@class='selectedAcc']//h4"
    list_bloks = '//div[@class="selectedAcc"]//div[contains(@class,"accordion_")]'
    list_yes = "//input[@name='YesNoFieldDiv' and @value='Yes']"


class SF_2(object):
    # Описание бизнеса
    button_next = "//span[text()='Вперед']"
    button_finish = "//span[text()='Завершить задачу']"
    criterias = '//div[@class="control-block"]/div[not(contains(@class,\'control-div-label\')) and position()=1]'


class SF_3(object):
    # Описание бизнеса
    button_next = "//span[text()='Вперед']"
    button_finish = "//span[text()='Завершить задачу']"
    list_subjects = '//div[@style="padding: 8px 0px; float: left; width: 15%;"]/div'
    list_yes = "//input[@name='YesNoFieldDiv' and @value='Yes']"


class SF_4(object):
    # Описание бизнеса
    button_next = "//span[text()='Вперед']"
    button_finish = "//span[text()='Завершить задачу']"

    # Общее
    chislo_polnix_let_raboti_Zaemshika = '//*[@id="borrowerFactEmployment"]'
    chislo_polnix_let_osnovnogo_sobstvenika = '//*[@id="ownerBusinessPeriod"]'
    data_pervogo_postupleniya_viruchki = '//*[@class="date-picker-custom-input"]'
    kolichestvo_rabotneykov_Subekta = '//*[@id="employeeNum"]'
    fizicheskii_pokazatel_declariruemoe = '//*[@id="physicalIndicatorDeclared"]'
    fizicheskii_pokazatel_fakticheskoe = '//*[@id="physicalIndicatorFact"]'
    # Контрагенты Заемщика
    section_kontragenti_Zaemshika = "//div[contains(@class,'accord') and .//div[contains(text(),'Контрагенты Заемщика')]]"
    postavshik_dolia_krupneishego_kontragenta = "//*[@id='[0].contractorCount']"
    postavshik_kolichestvo = "//*[@id='[0].majorProviderContract']"
    pokupateli_dolia_krupneishego_kontragenta = "//*[@id='[1].contractorCount']"
    pokupateli_kolichestvo = "//*[@id='[1].majorProviderContract']"
    spravka_o_rezultatakh_vyezda_namesto_vedeniia_biznesa_clienta = \
        "//table[//*[contains(text(),'Информация о бизнесе')]]//textarea[2]"
    Sootvetstvie_zaiavlennoi_Clientom_informatcii_fakticheskoi = \
        "//table[.//*[contains(text(),'Информация о бизнесе')]]//input[@value='Yes']"
    # Обязательства
    section_obyazatelstva = "//div[contains(@class,'accord') and .//div[contains(text(),'Обязательства')]]"
    obyazatelstva_credit_cards = "//*[@id='[0].creditCards']"
    obyazatelstva_potrebitelskie_credits = "//*[@id='[0].consumerLoans']"
    obyazatelstva_Kredity_na_priobretenie_transportnyh_sredstv = "//*[@id='[0].creditsTransport']"
    obyazatelstva_Kredity_na_priobretenie_nedvizhimosti = "//*[@id='[0].creditsTransportRealEstate']"
    # Дополнительно для АПК
    section_dopolnitelno_for_apk = "//div[contains(@class,'accord') and .//div[contains(text(),'Дополнительно')]]"
    apk_Dannie_o_straxovanii_zaemshikom_selskohozyastvennix_riskov = "//*[@id='insuranceInformation']"
    apk_Dannie_o_nalichii_v_shtate_neobhodimyh_profilnyh_specialistov = "//*[@id='availabilitySpecialists']"
    # Справка о результатах выезда
    section_spravka_o_resultatah_viezda = "//div[contains(@class,'accord') and .//div[contains(text(),'Справка')]]"
    spravka_informaciya_o_businese = \
        "//div[./div[contains(@class,'accord')] and .//*[contains(text(),'Справка')]]//table//textarea[2]"
    spravka_sootvetstsvie_zayavlennoi_clientom_info = \
        "//div[./div[contains(@class,'accord')] and .//*[contains(text(),'Справка')]]//table//input[@value='Yes']"
    date_2_balance = "//input[ancestor::tr[.//td[contains(text(),'Дата 2')]]]"
    date_1_inputs = "//table//input"

    active_denezhnye_sredstva_v_kasse = ".//*[@id='active[25].value.confirmByCust[0]']"
    active_denezhnye_sredstva_na_schetax = ".//*[@id='active[26].value.confirmByCust[0]']"
    active_tovary = "//*[@id='active[16].value.confirmByCust[0]']"
    active_zdaniia_i_sooruzheniia = "//*[@id='active[2].value.confirmByCust[0]']"
    passive_dolgosrochnye_kredity = ".//*[@id='passive[7].value.confirmByCust[0]']"
    passive_kratkosrochnye_kredity = ".//*[@id='passive[13].value.confirmByCust[0]']"
    passive_nakoplennyi_kapital = ".//*[@id='passive[1].value.confirmByCust[0]']"

    pp_active_denezhnye_sredstva_v_kasse = ".//*[@id='active[25].value.confirmByCust[1]']"
    pp_active_denezhnye_sredstva_na_schetax = ".//*[@id='active[26].value.confirmByCust[1]']"
    pp_active_tovary = ".//*[@id='active[16].value.confirmByCust[1]']"
    pp_active_zdaniia_i_sooruzheniia = ".//*[@id='active[2].value.confirmByCust[1]']"
    pp_passive_dolgosrochnye_kredity = ".//*[@id='passive[7].value.confirmByCust[1]']"
    pp_passive_kratkosrochnye_kredity = ".//*[@id='passive[13].value.confirmByCust[1]']"
    pp_passive_nakoplennyi_kapital = ".//*[@id='passive[1].value.confirmByCust[1]']"

    pp_dat3_active_denezhnye_sredstva_v_kasse = ".//*[@id='active[25].value.confirmByCust[2]']"
    pp_dat3_active_denezhnye_sredstva_na_schetax = ".//*[@id='active[26].value.confirmByCust[2]']"
    pp_dat3_active_tovary = ".//*[@id='active[16].value.confirmByCust[2]']"
    pp_dat3_active_zdaniia_i_sooruzheniia = ".//*[@id='active[2].value.confirmByCust[2]']"
    pp_dat3_passive_dolgosrochnye_kredity = ".//*[@id='passive[7].value.confirmByCust[2]']"
    pp_dat3_passive_kratkosrochnye_kredity = ".//*[@id='passive[13].value.confirmByCust[2]']"
    pp_dat3_passive_nakoplennyi_kapital = ".//*[@id='passive[1].value.confirmByCust[2]']"

    p3_active_denezhnye_sredstva_v_kasse = ".//*[@id='active[25].value.confirmByThirdParties[1]']"
    p3_active_denezhnye_sredstva_na_schetax = ".//*[@id='active[26].value.confirmByThirdParties[1]']"
    p3_active_tovary = ".//*[@id='active[16].value.confirmByThirdParties[1]']"
    p3_active_zdaniia_i_sooruzheniia = ".//*[@id='active[2].value.confirmByThirdParties[1]']"
    p3_passive_dolgosrochnye_kredity = ".//*[@id='passive[7].value.confirmByThirdParties[1]']"
    p3_passive_kratkosrochnye_kredity = ".//*[@id='passive[13].value.confirmByThirdParties[1]']"
    p3_passive_nakoplennyi_kapital = ".//*[@id='passive[1].value.confirmByThirdParties[1]']"

    # ОПиУ
    viruchka_ot_prodajy_tovara1 = './/tr[./td[contains(text(),\'Выручка от продажи товара №1\')]]' \
                                  '//input[contains(@id,"confirmByCust")]'
    nacenka_po_tovary1 = "//tr[./td[contains(text(),'Наценка по товару №1')]]" \
                         "//input[contains(@id,'margin.margin1.confirmByThirdDocs')]"
    prochie_doxody = "//tr[./td[contains(text(),'Прочие доходы')]]" \
                     "//input[contains(@id,\"confirmByCust\")]"
    sebestoimost_tovara1 = '//tr[./td[contains(text(),\'Себестоимость товара №1\')]]' \
                           '//input[contains(@id,\'netCost.netCost1.confirmByThirdDocs\')]'
    arenda_komunalnye_platezi = "//tr[./td[contains(text(),'Аренда и коммунальные платежи')]]" \
                                "//input[contains(@id,'confirmByCust')]"
    zarplata_s_nachisleniyami = "//tr[./td[contains(text(),'Зарплата с начислениями')]]" \
                                "//input[contains(@id,'confirmByCust')]"
    transportnie_rasxody = "//tr[./td[contains(text(),'Транспортные расходы')]]" \
                           "//input[contains(@id,'confirmByCust')]"
    uslugi_banka_i_svyazy = "//tr[./td[contains(text(),'Услуги банка и связи')]]" \
                            "//input[contains(@id,'confirmByCust')]"
    prochie_postoyannie_rasxody = "//tr[./td[contains(text(),'Прочие и постоянные расходы')]]" \
                                  "//input[contains(@id,'confirmByCust')]"
    pogashenie_dolga_v_RSHB = '//div[text()="Погашение основного долга в РСХБ"]' \
                              '//following::input[contains(@id,"debtPayments.rshb")]'
    zona_otvetstvennosti = "//textarea[@id='areaResponsibility']"
    # Расшифровка финансовой информации
    dlytelnost_kartoteki = ".//input[@id='cardDuration']"
    section_dynamica_viruchki_i_oborotov = \
        "//div[text()='Динамика выручки и оборотов по р/с']"
    viruchka = "//td[text()='Выручка (руб.)']/following-sibling::td"
    pribl_ubytok = "//td[text()='Прибыль/убыток (руб.)']/following-sibling::td"
    oboroty_po_rs = "//td[text()='Обороты по р/с (руб.)']/following-sibling::td"
    section_otchet_o_pribyli_i_ubytkah = "//div[contains(text(),'Отчет о прибылях и убытках по')]"
    sredniaia_vyruchka_dlya_celei_opredeleniya_potentciala = ".//input[@id='avgReceipts']"
    viruchka_po_dannim_offical_otchetnosti = \
        "//*[contains(text(),'Выручка (по данным')]//following-sibling::td"
    pribl_ubytok_po_dannim_offical_otchetnosti = \
        "//*[contains(text(),'Прибыль / убыток (по данным')]//following-sibling::td"
    zaemshik_prodostavil_spravky_o_creditnom_portfele = \
        "//tr[.//td[contains(text(),'Заемщик предоставил справку о кредитном портф')]]" \
        "//input[@value='Yes']"
    section_lizingovye_obyazatelstva = "//div[contains(text(),'Лизинговые обязательства')]"
    ostatok_lizingovyh_obyazatelstv = ".//*[@id='totalLiability']"
    summa_tekushix_lizingoyh_obyazatelstv = \
        ".//*[@id='currentLiability']"
    nalichie_skityx_poter = "//div[./div[text()='Наличие скрытых потерь']]//input[@value='Yes']"
    # Шаг Общая информация
    section_common_info = "//div[@class='accordion_white' and .//div[contains(text(),'Общая информаци')]]"
    credit_level_prinyatiya_resheniya = ".//textarea[contains(@id,'decisionLevel')]"
    section_analyz_izmeneniya_sobstvennogo_kapitala = \
        "//div[contains(@class,'accordion') and .//*[contains(text(),'Анализ изменения')]]"
    sobstvenniy_kapital_na_Data_2 = "//input[./parent::div[./preceding-sibling::" \
                                    "div[contains(text(),'Собственный капитал на Дата 2')]]]"
    sobstvenniy_kapital_na_Data_3 = "//input[./parent::div[./preceding-sibling::" \
                                    "div[contains(text(),'Собственный капитал на Дата 3')]]]"
    nakoplennaya_chistaya_prybl = "//input[./parent::div[./preceding-sibling::" \
                                  "div[contains(text(),'Накопленная Чистая Прибыль')]]]"

    # Нефинансовые факторы
    b1_field = "//tr/td[text()='B1']/following-sibling::*//div[@class='dropDownArea']"
    b2_field = "//tr/td[text()='B2']/following-sibling::*//div[@class='dropDownArea']"
    b3_field = "//tr/td[text()='B3']/following-sibling::*//div[@class='dropDownArea']"
    b4_field = "//tr/td[text()='B4']/following-sibling::*//div[@class='dropDownArea']"
    b5_field = "//tr/td[text()='B5']/following-sibling::*//div[@class='dropDownArea']"
    b6_field = "//tr/td[text()='B6']/following-sibling::*//div[@class='dropDownArea']"
    b7_field = "//tr/td[text()='B7']/following-sibling::*//div[@class='dropDownArea']"
    b8_field = "//tr/td[text()='B8(З)']/following-sibling::*//div[@class='dropDownArea']"
    b9_field = "//tr/td[text()='B9']/following-sibling::*//div[@class='dropDownArea']"
    b10_field = "//tr/td[text()='B10']/following-sibling::*//input[@value='Yes']"
    b11_field = "//tr/td[text()='B11']/following-sibling::*//input[@type='text']"
    b12_field = "//tr/td[text()='B12']/following-sibling::*//div[@class='dropDownArea']"
    b13_field = "//tr/td[text()='B13']/following-sibling::*//input[@value='Yes']"
    b16_field = "//tr/td[text()='B16']/following-sibling::*//input[@type='text']"
    b17_field = "//tr/td[text()='B17']/following-sibling::*//div[@class='dropDownArea']"
    b19_field = "//tr/td[text()='B19']/following-sibling::*//div[@class='dropDownArea']"
    b25_field = "//tr/td[text()='B25']/following-sibling::*//div[@class='dropDownArea']"
    b26_field = "//tr/td[text()='B26']/following-sibling::*//input[@value='Yes']"
    b27_field = "//tr/td[text()='B27']/following-sibling::*//input[@value='Yes']"
    b28_field = "//tr/td[text()='B28']/following-sibling::*//input[@type='text']"
    b29_field = "//tr/td[text()='B29']/following-sibling::*//input[@value='Yes']"
    b30_field = "//tr/td[text()='B30']/following-sibling::*//div[@class='dropDownArea']"
    b31_field = "//tr/td[text()='B31']/following-sibling::*//div[@class='dropDownArea']"

    b1 = ".//*[@id='1']"
    b2 = ".//*[@id='3']"
    b3 = ".//*[@id='3']"
    b4 = ".//*[@id='4']"
    b5 = ".//*[@id='4']"
    b6 = ".//*[@id='3']"
    b7 = ".//*[@id='1']"
    b8 = ".//*[@id='1']"
    b9 = ".//*[@id='1']"
    b12 = ".//*[@id='1']"
    b17 = ".//*[@id='1']"
    b19 = ".//*[@id='1']"
    b25 = ".//*[@id='2']"
    # b30 = ".//*[@id='kjsahdkjahdkahs']"
    b31 = ".//*[@id='1']"
    # Предупреждающие сигналы
    c3 = ".//*[@id='3']"
    c3_field = "//td[text()='C3']/following-sibling::*//div[@class='dropDownArea']"
    c4 = ".//*[@id='3']"
    c4_field = "//td[text()='C4']/following-sibling::*//div[@class='dropDownArea']"
    c12 = ".//*[@id='2']"
    c12_field = "//td[text()='C12']/following-sibling::*//div[@class='dropDownArea']"
    c13 = ".//*[@id='2']"
    c13_field = "//td[text()='C13']/following-sibling::*//div[@class='dropDownArea']"
    c14 = ".//*[@id='1']"
    c14_field = "//td[text()='C3']/following-sibling::*//div[@class='dropDownArea']"
    c16_field = "//td[text()='C16.1.']/following-sibling::*//input[@type='text']"
    c_list_yes = "//input[@value='No' and @name='YesNoFieldDiv']"


class SF_5(object):
    section_stop_parametr = "//div[contains(text(),'Стоп-параметры')]"
    stop_vipolnenie_usloviy = "//div[./div[@class='accordion_grey' and .//div[contains(text(),'Стоп-параметры')]]]" \
                              "//input[@value='Yes']"
    stop_vivod = "//div[./div[@class='accordion_grey' and .//div[contains(text(),'Стоп-параметры')]]]" \
                 "//textarea[@id!='']"
    vivod = ".//*[@id='conclusion']"
    button_next = "//span[text()='Вперед']"
    section_KA = './/div[contains(@class,"accordion_") and .//div[contains(text(),"Кредитный аналитик")]]'
    KA_reshenie = '//div[./div[@class="accordion_grey" and .//div[contains(text(),"Кредитный аналитик")]]]' \
                  '//div[@class="dropDownArea"]'
    KA_reshenie_true = '//*[@id="true"]'


class SF_6(object):
    button_next = "//span[text()='Вперед']"
    button_finish = "//span[text()='Завершить задачу']"
    some_text = "some_text"
    list_subjects = '//div[@style="padding: 8px 0px; float: left; width: 15%;"]/div'
    # Общие документы
    section_1_1 = "//div[starts-with(text(),'1.1')]"
    obshie_docs = "//div[text()='Документ необходимо предоставить']/following-sibling::div//input[@value='No']"
    section_vivody_i_comments_po_rezultatam = "//div[contains(@class,'accordion') and " \
                                              ".//div[contains(text()," \
                                              "'Выводы и комментарии по результатам')]]"
    obshaya_pravosposobnost = "//div[@class='dropDownArea' and " \
                              "./preceding-sibling::div[text()='Общая правоспособность']]"
    obshaya_pravosposobnost_val = ".//div[@class='dropDownMenu']/div[text()='Подтверждено']"

    scpecial_pravosposobnost = "//div[@class='dropDownArea' and " \
                               "./preceding-sibling::div[contains(text()," \
                               "'Специальная правоспособность')]]"
    scpecial_pravosposobnost_val = ".//div[@class='dropDownMenu']/div[text()='Подтверждено']"

    ogranicheniya_vidov_deyatelnosty = "//div[@class='dropDownArea' and " \
                                       "./preceding-sibling::div[contains(text()," \
                                       "'Ограничения видов деятельности')]]"
    ogranicheniya_vidov_deyatelnosty_val = ".//div[@class='dropDownMenu']/div[contains(text(),'Не ограничен')]"

    otnoshenie_k_subject_estestv_monopoly = "//div[@class='dropDownArea' and " \
                                            "./preceding-sibling::div[contains(text()," \
                                            "'Отношение к субъектам естественных монополий')]]"
    otnoshenie_k_subject_estestv_monopoly_val = ".//div[@class='dropDownMenu']/div[contains(text(),'Не относится')]"

    otnoshenie_k_subject_deystbiya_zakona = "//div[@class='dropDownArea' and " \
                                            "./preceding-sibling::div[contains(text()," \
                                            "'Отношение к субъектам действия закона')]]"
    otnoshenie_k_subject_deystbiya_zakona_val = ".//div[@class='dropDownMenu']/div[contains(text(),'Не подтверждено')]"

    # 1.2. Analyze ...
    sections_1_2 = "//div[starts-with(text(),'1.2.')]"
    grn_number = ".//*[@id='grnNumber']"
    nalichie_izmeneniy = "//div[contains(text(),'Наличие изменений')]/following-sibling::div" \
                         "//input[@value='No']"
    uchastniki_actionery_obshestva = "//div[text()='Комментарий']/../preceding-sibling::div[1]//input"

    # 1.3. Analyze ...
    sections_1_3 = "//div[starts-with(text(),'1.3.')]"
    dop_docs = obshie_docs

    # Выводы по результатам анализа органов управления участников сделки и полномчий
    section_vivody_po_rezultatam = "//div[contains(@class,'accordion') and " \
                                   ".//div[contains(text(),'Выводы  по результатам')]]"

    vivody_po_rezultatam_val = "//div[@class='dropDownMenu']/div[1]"
    vivody_po_rezultatam = "//div[@class='dropDownArea'  and " \
                           "./preceding-sibling::div[contains(text(),'Выводы  по результатам')]]"
    # 1.4. Анализ сделки на предмет наличия принзнаков крупной сделки
    section_1_4 = "//div[starts-with(text(),'1.4.')]"
    sdelka = "//div[@class='dropDownArea' and " \
             "./preceding-sibling::div[contains(text(),'Сделка')]]"
    sdelka_val = ".//div[@class='dropDownMenu']/div[contains(text(),'Сделка не')]"
    sdelka_docs = obshie_docs
    vivod_po_rezultatam_analyza_krupnoy_sdelki = "//div[@class='dropDownArea' and " \
                                                 "./preceding-sibling::div[contains(text()," \
                                                 "'Вывод по результатам')]]"
    vivod_po_rezultatam_analyza_krupnoy_sdelki_val = sdelka_val

    # 1.5. Анализ сделки на предмет наличия признаков сделки, в совершении которой имеется заинтересованность
    zainteresovannost_v_sovershenii_sdelki = "//div[@class='dropDownArea'  and " \
                                             "./preceding-sibling::div[contains(text(),'Заинтересованность в совершении ')]]"
    zainteresovannost_doc = obshie_docs
    zainteresovannost_v_sovershenii_sdelki_val = ".//div[@class='dropDownMenu']/div[contains(text(),'Имеется')]"

    vivod_zainteresovannost_v_sovershenii_sdelki = "//div[@class='dropDownArea'  and " \
                                                   "./preceding-sibling::div[contains(text(),'Заинтересованность в совершении ')]]"
    vivod_zainteresovannost_v_sovershenii_sdelki_val = ".//div[@class='dropDownMenu']/div[contains(text(),'имеется')]"
    section_1_5 = "//div[starts-with(text(),'1.5')]"

    # 1.6. Анализ сделки на предмет наличия дополнительных ограничений полномочий
    sections_1_6 = "//div[starts-with(text(),'1.6')]"

    polnomochiya_edinolichnogo_icpolnitelnogo_organa = "//div[@class='dropDownArea'  and " \
                                                       "./preceding-sibling::div[contains(text(),'Полномочия')]]"
    polnomochiya_edinolichnogo_icpolnitelnogo_organa_val = ".//div[@class='dropDownMenu']/div[contains(text(),'Нет')]"
    plnomochiya_doc = obshie_docs
    vivod_polnomochiya_edinolichnogo_icpolnitelnogo_organa = "//div[@class='dropDownArea'  and " \
                                                             "./preceding-sibling::div[contains(text(),'Вывод по результатам')]]"
    vivod_polnomochiya_edinolichnogo_icpolnitelnogo_organa_val = ".//div[@class='dropDownMenu']/div[1]"

    # 1.7. Общие выводы и рекомендации
    section_1_7 = "//div[starts-with(text(),'1.7')]"
    itogoviy_vivod = "//div[@class='dropDownArea'  and " \
                     "./preceding-sibling::div[contains(text(),'Вывод')]]"
    itogoviy_vivod_val = ".//div[@class='dropDownMenu']/div[1]"


class SF_7(object):
    button_next = "//span[text()='Вперед']"
    button_finish = "//span[text()='Завершить задачу']"
    section_zam_dir = "//div[contains(@class,'accordion') and .//div[contains(text(),'Зам.')]]"
    reshenie = "//div[@class='dropDownArea'  and " \
               "./preceding-sibling::div[contains(text(),'Решение')]]"
    reshenie_val = ".//div[@class='dropDownMenu']/div[1]"


class SF_8(object):
    button_next = "//span[text()='Вперед']"
    button_finish = "//span[text()='Завершить задачу']"
    podtverzdenie = "//div[@class='dropDownDiv']/div[@class='dropDownArea']"
    podtverzdenie_val = ".//div[@class='dropDownMenu']/div[1]"
    section_bux_balanse = "//div[contains(@class,'accordion') and .//div[contains(text(),'Бухгалтер')]]"
    section_otchet = "//div[contains(@class,'accordion') and .//div[contains(text(),'Отчет')]]"
    section_finans = "//div[contains(@class,'accordion') and .//div[contains(text(),'Финансовые')]]"
    section_pokazateli = "//div[contains(@class,'accordion') and .//div[contains(text(),'Показатели')]]"
    section_predup = "//div[contains(@class,'accordion') and .//div[contains(text(),'Предупреждающие')]]"
    # 8.2 Заключение Андеррайтера
    section_uchastniki_sdelki = "//div[contains(@class,'accordion') and .//div[contains(text(),'Участники')]]"
    section_zaprosheno = "//div[contains(@class,'accordion') and .//div[contains(text(),'Запрошено')]]"
    section_vivod_and_recomend = "//div[contains(@class,'accordion') and .//div[contains(text(),'Вывод')]]"
    gsk_uchastniki_sdelki = ".//*[@id='gsk']"
    anderraiter_soglasen_uchastniki_sdelki = "//input[@value='Yes']"
    forma_predostavleniya_zaprosheno = "//div[@class='dropDownDiv']/div[@class='dropDownArea']"
    forma_predostavleniya_zaprosheno_val = ".//div[@class='dropDownMenu']/div[1]"
    znachenie_vivod = "//div[@class='dropDownDiv']/div[@class='dropDownArea']"
    znachenie_vivod_val = ".//div[@class='dropDownMenu']/div[1]"
    obosnavanie_vivod = ".//*[@id='outputJustification']"
    # 8.3 Проект решения
    section_anderrater = "//div[contains(@class,'accordion') and .//div[contains(text(),'Андеррайтер')]]"
    reshenie_underrater = "//div[@class='dropDownDiv']/div[@class='dropDownArea']"
    reshenie_underrater_val = ".//div[@class='dropDownMenu']/div[1]"


class SF_9(object):
    button_next = "//span[text()='Вперед']"
    button_back = "//span[text()='Назад']"
    button_finish = "//span[text()='Завершить задачу']"
    non_opened_sections = "//div[@class='accordion_white']"
    informaciya_po_cerditnomy_dogovoru = "//span[contains(text(),'Информация')]/ancestor::button"
    all_links = "//div[contains(@class,'accordion')]/following-sibling::*//a[contains(text(),'оговор')]"
    podtverzdenies = "//input[@value='Yes']"
    verify_opened_information = "//*[contains(text(),'Назад')]"


