import openpyxl
import random
from openpyxl import load_workbook
import openpyxl.styles.borders
from openpyxl.styles import PatternFill, Border, Side, Alignment, Protection, Font
from openpyxl.utils import get_column_letter

wb = load_workbook('D:\\RSHB_ISPZ\\list2.xlsx')
ws = wb[wb.sheetnames[0]]
wc = (ws['B:B'])[1:]

for x in wc:
    if len(str(x.value)) == 12:
        x.value = str(random.randint(100000000, 999999999)) + '111'
    else:
        x.value = str(random.randint(1000000, 9999999)) + '111'
for x in range(ws['B:B']):
    print((ws['B:B'])[x])

wb.save(filename='D:\\RSHB_ISPZ\\list2.xlsx')
wb.close()
# myfile = open("list.csv", 'r', encoding='cp1251')
# mystring = myfile.readlines()
# myfile.close()
#
# for x in range(mystring.__len__()):
#     mystring[x] = mystring[x].strip('\n').split(';')
#
# wb = openpyxl.Workbook()
# file = 'D:\\openpyxl.xlsx'
# ws1 = wb.active
# ws1.title = "list1"
#
# border = Border(right=Side(border_style='thin', color='00000000'))
#
# for raw in range(mystring.__len__()):
#     for x in range(len(mystring[raw])):
#         _ = ws1.cell(column=x+1, row=raw+1, value=mystring[raw][x], ).border = border
# print(ws1['A3'].value)
#
# wb.save(filename=file)

# for row in range(1, 40):
#     ws1.append(range(600))
#
# ws2 = wb.create_sheet(title="Pi")
# ws2['F5'] = 3.14
# ws3 = wb.create_sheet(title="Data")
# for row in range(10, 20):
#     for col in range(27, 54):
#         _ = ws3.cell(column=col, row=row, value="{0}".format(get_column_letter(col)))
# print(ws3['AA10'].value)
# wb.save(filename=file)

import requests

url = "https://api.telegram.org/bot577567787:AAFbmA3Pznp8SNB4NGvYpwi3lUlH28T9IME/" + "getUpdates"
proxy = dict(http='http://ishakirov:shok9894@proxy.tsc.ts:8080',
             https='http://ishakirov:shok9894@proxy.tsc.ts:8080')

resp = requests.get(url, proxies=proxy)
print(resp.json())

