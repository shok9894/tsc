# debtorsData = open("D:\\RSHB_ISPZ\\debtorsData.csv", 'r')
# datr = debtorsData.readlines()
# debtorsData.close()
# for x in range(len(datr)):
#     datr[x] = datr[x].strip(':\n').strip('"').split(';')
#
# print(datr)
# from openpyxl import load_workbook
# from data import Data
# wb = load_workbook('D:\\RSHB_ISPZ\\debtorsData.xlsx')
# ws = wb[Data.debtor1]
# wc = (ws['B:C'])
#
# string1 = [x.value for x in wc]
#
# for x in wc:
#     if len(str(x.value)) == 12:
#         pass
#     else:
#         pass
# for x in range(ws['B:B']):
#     print((ws['B:B'])[x])
#
# wb.save(filename='D:\\RSHB_ISPZ\\list2.xlsx')
# wb.close()
#
# from lxml import etree
#
# xmlFile = "debtorsData.xml"
# with open(xmlFile, encoding='UTF-8') as fobj:
#     xml = fobj.read()
#
# et = etree.fromstring(xml)
#
# element = et.xpath('//debtor')
# for x in element:
#     print(x.attrib('text'))
#
# etree.strip_attributes()

# from ctypes import *
# import time, os
#
# ok = windll.user32.BlockInput(True)
# block = 10  # время блокировки
# if ok:
#     print('Клаватаура и мышь заблокированы:')
#     current_time = time.time()
#     diff = 0
#     while diff < block:
#         diff = time.time() - current_time
#         time.sleep(1)
#         os.system("cls")
#         print('Клавиатура и мышь заблокированы:{0:.0f}'.format(diff))
#     windll.user32.BlockInput(False)  # разблокируем через указанное время

# import threading
# import pythoncom
# import pyHook
#
#
# def keypressed(event):
#     if event.Ascii == 13:
#         keys = '<ENTER>'
#     elif event.Ascii == 8:
#         keys = '<BACK SPACE>'
#     elif event.Ascii == 9:
#         keys = '<TAB>'
#     else:
#         keys = chr(event.Ascii)
#     print
#     keys
#
#
# class Keylogger(threading.Thread):
#     def __init__(self):
#         threading.Thread.__init__(self)
#         self.event = threading.Event()
#
#     def run(self):
#         obj = pyHook.HookManager()
#         obj.KeyDown = keypressed
#         obj.HookKeyboard()
#         pythoncom.PumpMessages()
#
#
# k = Keylogger()
# k.run()

# import keyboard
# import mouse
# keyboard.block_key('Alt')

# import random
# from openpyxl import load_workbook
# from data import Data
# from page import ExtFunction
#
# try:
#     wb = load_workbook(Data.DeptorsFile)
#     ws = wb[wb.sheetnames[0]]
#
#     wc = (ws['B:B'])[1:]
#     wc2 = (ws['A:A'])[2:]
#     debtors = ExtFunction.debtors_list()
#     debtors_list = list(map(lambda x: x.attrib['text'], debtors))
#     for x in wc:
#         inn = str(random.randint(1000000, 9999999))
#         if len(str(x.value)) == 12:
#             x.value = inn + '11111'
#         else:
#             x.value = inn + '111'
#
#     for (y, d) in zip(wc2, debtors_list):
#         y.value = str(d)
#     wb.save(filename=Data.DeptorsFile)
#     wb.close()
#     print(True)
# except Exception as err:
#     print("\nОшибка при работе с файлом", err, sep='\n\n')
#     print(False)

import requests
import json

s = requests.get('http://bcvm187:8180/collect-api/login?j_username=puser&j_password=Password123')
data = s.json()
d = requests.get('http://bcvm187:8180/collect-api/login?j_username=puser&j_password=Password123')

print(s.text)
