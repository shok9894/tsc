import random
import time
from datetime import date


class Data(object):
    user = "puser"
    password = "Password123"
    wait_time = 10
    login_page_title = "RSHB SME"
    base_page_title = "РСХБ СМЕ"
    Radio_Quality_Scan_Value = 'Yes'
    DeptorsFile = "D:\\RSHB_ISPZ\\list2.xlsx"
    DeptorsData = "D:\\RSHB_ISPZ\\debtorsData.csv"
    gsz_name = "ГК Связные ромашки №%s" % random.randint(1, 999)
    nomer_spiska = 99
    now = date.today().strftime("%d.%m.%Y")
    zalog = 'Залоги'

    # debtor1 = 'ИП Елкин В.И'
    # debtor2 = 'ООО Промитей'
    # debtor3 = 'ОАО Себас'
    # debtor4 = 'ОАО Поток-2'
    # debtor5 = 'Петров'
    # debtor1 = 'ИП Елкин В.И'
    # debtor2 = 'ООО Промитей'
    # debtor3 = 'ОАО Себас'
    # debtor4 = 'ОАО Поток-2'
    # debtor5 = 'Петров'
